define("Customer360/frmCustomer", function() {
    return function(controller) {
        function addWidgetsfrmCustomer() {
            this.setDefaultUnit(voltmx.flex.DP);
            var flxMain = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(voltmx.flex.DP);
            var SideMenu = new com.hcl.menu.SideMenu({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "focusSkin": "sknFlxTrans",
                "height": "100%",
                "id": "SideMenu",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "60dp",
                "zIndex": 10,
                "appName": "SBCommon",
                "overrides": {
                    "imgLogo": {
                        "src": "sblogo.png"
                    },
                    "imgLogout": {
                        "src": "icon_logout.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxRight = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "focusSkin": "sknFlxSrcTrans",
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "60dp",
                "pagingEnabled": false,
                "right": "0dp",
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "sknFlxSrcTrans",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(voltmx.flex.DP);
            var FormHeader = new com.hcl.hdr.FormHeader({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "60px",
                "id": "FormHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexMenu",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "imgLogout": {
                        "src": "icon_logout.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxSrc = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSrc",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "24dp",
                "isModalContainer": false,
                "top": "24dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSrc.setDefaultUnit(voltmx.flex.DP);
            var flxSrch = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "48dp",
                "id": "flxSrch",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSrch.setDefaultUnit(voltmx.flex.DP);
            var SrchTextBox = new com.hcl.srchTextBox.SrchTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "focusSkin": "slFFocusbox",
                "height": "100%",
                "id": "SrchTextBox",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTextBox",
                "top": "0dp",
                "width": "63%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "SrchTextBox": {
                        "height": "100%",
                        "left": "0dp",
                        "top": "0dp",
                        "width": "63%"
                    },
                    "imgSrch": {
                        "src": "icon_srch.png"
                    },
                    "txtSrch": {
                        "placeholder": "Search with CIF"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSrch.add(SrchTextBox);
            var flxCustomerDetails = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCustomerDetails",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "24dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerDetails.setDefaultUnit(voltmx.flex.DP);
            var SubHdr = new com.hcl.subHdr.SubHdr({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "45dp",
                "id": "SubHdr",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": "0dp",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "SubHdr": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "lblSubHdr": {
                        "text": "Customer Information"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCustomerInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "flxCustomerInfo",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [16, 0, 16, 16],
                "paddingInPixel": true
            }, {});
            flxCustomerInfo.setDefaultUnit(voltmx.flex.DP);
            var flxProfileType = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxProfileType",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileType.setDefaultUnit(voltmx.flex.DP);
            var lblProfileType = new voltmx.ui.Label({
                "id": "lblProfileType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Profile Type",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rdoProfileType = new voltmx.ui.RadioButtonGroup({
                "id": "rdoProfileType",
                "isVisible": true,
                "masterData": [
                    ["App", "Application"],
                    ["CBO", "Cash backed only"],
                    ["Col", "Collateral"]
                ],
                "selectedKey": "App",
                "skin": "slRadioButtonGroup",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileType.add(lblProfileType, rdoProfileType);
            var flxCIFNumber = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCIFNumber",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCIFNumber.setDefaultUnit(voltmx.flex.DP);
            var CIFNumber = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CIFNumber",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "CIF Number"
                    },
                    "lblDetailValue": {
                        "height": "40dp",
                        "text": "0234567891",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCIFNumber.add(CIFNumber);
            var flxEntityName = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEntityName",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEntityName.setDefaultUnit(voltmx.flex.DP);
            var EntityName = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "EntityName",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "width": "100%"
                    },
                    "lblText": {
                        "text": "Entity Name"
                    },
                    "txtBox": {
                        "text": "80/20 MARKETING LIMITED",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEntityName.add(EntityName);
            var flxEntiryRegNum = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEntiryRegNum",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEntiryRegNum.setDefaultUnit(voltmx.flex.DP);
            var EntityRegNum = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "EntityRegNum",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "width": "100%"
                    },
                    "lblText": {
                        "text": "Entity Registration Number/NIF"
                    },
                    "txtBox": {
                        "text": "80/20 MARKETING LIMITED",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEntiryRegNum.add(EntityRegNum);
            var flxEntityType = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEntityType",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEntityType.setDefaultUnit(voltmx.flex.DP);
            var EntityType = new com.hcl.lblList.LabelList({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "EntityType",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "flxDropDwnList": {
                        "height": "30dp",
                        "right": "3dp",
                        "top": "3dp",
                        "width": "30dp"
                    },
                    "imgDropDwn": {
                        "height": "30dp",
                        "src": "icon_dropdwn.png",
                        "top": "0dp",
                        "width": "30dp"
                    },
                    "lblDetail": {
                        "text": "Entity Type"
                    },
                    "listData": {
                        "masterData": [
                            ["CC", "Close Corporation"],
                            ["C", "Company"],
                            ["T", "Trust"],
                            ["P", "Partnership"]
                        ],
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEntityType.add(EntityType);
            var flxIdentityNum = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIdentityNum",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxIdentityNum.setDefaultUnit(voltmx.flex.DP);
            var IdentityNumber = new com.hcl.lblList.LabelList({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "IdentityNumber",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "flxDropDwnList": {
                        "height": "30dp",
                        "right": "3dp",
                        "top": "3dp",
                        "width": "30dp"
                    },
                    "imgDropDwn": {
                        "height": "30dp",
                        "src": "icon_dropdwn.png",
                        "top": "0dp",
                        "width": "30dp"
                    },
                    "lblDetail": {
                        "text": "Identity Number"
                    },
                    "listData": {
                        "masterData": [
                            ["None", "None"],
                            ["FCN", "Financial Card Number"]
                        ],
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxIdentityNum.add(IdentityNumber);
            var flxFullLegalName = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFullLegalName",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxFullLegalName.setDefaultUnit(voltmx.flex.DP);
            var FullLegalName = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "FullLegalName",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "width": "100%"
                    },
                    "lblText": {
                        "text": "Full Legal Name"
                    },
                    "txtBox": {
                        "text": "80/20 MARKETING LIMITED",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFullLegalName.add(FullLegalName);
            var flxRegolatorySector = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRegolatorySector",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRegolatorySector.setDefaultUnit(voltmx.flex.DP);
            var RegulatorySector = new com.hcl.lblList.LabelList({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "RegulatorySector",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "flxDropDwnList": {
                        "height": "30dp",
                        "right": "3dp",
                        "top": "3dp",
                        "width": "30dp"
                    },
                    "imgDropDwn": {
                        "height": "30dp",
                        "src": "icon_dropdwn.png",
                        "top": "0dp",
                        "width": "30dp"
                    },
                    "lblDetail": {
                        "text": "Identity Number"
                    },
                    "listData": {
                        "masterData": [
                            ["None", "None"],
                            ["FCN", "Financial Card Number"]
                        ],
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRegolatorySector.add(RegulatorySector);
            var flxISICCode = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxISICCode",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxISICCode.setDefaultUnit(voltmx.flex.DP);
            var ISICCode = new com.hcl.lblList.LabelList({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "ISICCode",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "flxDropDwnList": {
                        "height": "30dp",
                        "right": "3dp",
                        "top": "3dp",
                        "width": "30dp"
                    },
                    "imgDropDwn": {
                        "height": "30dp",
                        "src": "icon_dropdwn.png",
                        "top": "0dp",
                        "width": "30dp"
                    },
                    "lblDetail": {
                        "text": "ISIC Code"
                    },
                    "listData": {
                        "masterData": [
                            ["None", "None"],
                            ["M73", "Advertising and Marketing"]
                        ],
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxISICCode.add(ISICCode);
            var flxMarketSegment = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMarketSegment",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxMarketSegment.setDefaultUnit(voltmx.flex.DP);
            var MarketSegment = new com.hcl.lblList.LabelList({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "MarketSegment",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "flxDropDwnList": {
                        "height": "30dp",
                        "right": "3dp",
                        "top": "3dp",
                        "width": "30dp"
                    },
                    "imgDropDwn": {
                        "height": "30dp",
                        "src": "icon_dropdwn.png",
                        "top": "0dp",
                        "width": "30dp"
                    },
                    "lblDetail": {
                        "text": "Market Segment"
                    },
                    "listData": {
                        "masterData": [
                            ["None", "None"],
                            ["T", "Tier"]
                        ],
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMarketSegment.add(MarketSegment);
            var flxOtherBankers = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxOtherBankers",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxOtherBankers.setDefaultUnit(voltmx.flex.DP);
            var OtherBankers = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "OtherBankers",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "width": "100%"
                    },
                    "lblText": {
                        "text": "Other Bankers"
                    },
                    "txtBox": {
                        "text": "80/20 MARKETING LIMITED",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxOtherBankers.add(OtherBankers);
            var flxRouteToHeadOff = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRouteToHeadOff",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRouteToHeadOff.setDefaultUnit(voltmx.flex.DP);
            var RouteToHeadOff = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "RouteToHeadOff",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Route To Head Office"
                    },
                    "lblDetailValue": {
                        "height": "40dp",
                        "text": "No"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRouteToHeadOff.add(RouteToHeadOff);
            var flxRegistrationDate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRegistrationDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRegistrationDate.setDefaultUnit(voltmx.flex.DP);
            var lblRegDate = new voltmx.ui.Label({
                "id": "lblRegDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Registration Date",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var calCustInfo = new voltmx.ui.Calendar({
                "calendarIcon": "icon_cal.png",
                "dateComponents": [9, 9, 2015],
                "dateFormat": "dd/MM/yyyy",
                "day": 9,
                "formattedDate": "09/09/2015",
                "height": "40dp",
                "hour": 0,
                "id": "calCustInfo",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "month": 9,
                "seconds": 0,
                "skin": "sknSBCalender",
                "top": "5dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "year": 2015,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [16, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "noOfMonths": 1
            });
            flxRegistrationDate.add(lblRegDate, calCustInfo);
            var flxApplicantName = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApplicantName",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantName.setDefaultUnit(voltmx.flex.DP);
            var ApplicantsName = new com.hcl.lblList.LabelList({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "ApplicantsName",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "flxDropDwnList": {
                        "height": "30dp",
                        "right": "3dp",
                        "top": "3dp",
                        "width": "30dp"
                    },
                    "imgDropDwn": {
                        "height": "30dp",
                        "src": "icon_dropdwn.png",
                        "top": "0dp",
                        "width": "30dp"
                    },
                    "lblDetail": {
                        "text": "Applicant Name"
                    },
                    "listData": {
                        "masterData": [
                            ["None", "None"],
                            ["CM6990834", "Abrham, Basir"],
                            ["GN79827459", "ABINDAB,GODFREY"],
                            ["DR87874923", "ValueAbrham, Basir1"]
                        ],
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxApplicantName.add(ApplicantsName);
            var flxIDNum = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIDNum",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxIDNum.setDefaultUnit(voltmx.flex.DP);
            var IDNum = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "IDNum",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Route To Head Office"
                    },
                    "lblDetailValue": {
                        "height": "40dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxIDNum.add(IDNum);
            flxCustomerInfo.add(flxProfileType, flxCIFNumber, flxEntityName, flxEntiryRegNum, flxEntityType, flxIdentityNum, flxFullLegalName, flxRegolatorySector, flxISICCode, flxMarketSegment, flxOtherBankers, flxRouteToHeadOff, flxRegistrationDate, flxApplicantName, flxIDNum);
            flxCustomerDetails.add(SubHdr, flxCustomerInfo);
            var flxTabs = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTabs",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "24dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabs.setDefaultUnit(voltmx.flex.DP);
            var flxContactInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxContactInfo",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "10%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxContactInfo.setDefaultUnit(voltmx.flex.DP);
            var lblContactInfo = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblContactInfo",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Contact Information",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLineContInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxLineContInfo",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxLineContInfo.setDefaultUnit(voltmx.flex.DP);
            flxLineContInfo.add();
            flxContactInfo.add(lblContactInfo, flxLineContInfo);
            var flxOperationalInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxOperationalInfo",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "13%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxOperationalInfo.setDefaultUnit(voltmx.flex.DP);
            var lblOperationalInfo = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblOperationalInfo",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Operational Information",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxOpInfoLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxOpInfoLine",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxOpInfoLine.setDefaultUnit(voltmx.flex.DP);
            flxOpInfoLine.add();
            flxOperationalInfo.add(lblOperationalInfo, flxOpInfoLine);
            var flxPersonalInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPersonalInfo",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "11%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalInfo.setDefaultUnit(voltmx.flex.DP);
            var lblPersonalInfo = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblPersonalInfo",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Personal Information",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLinePersonalInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxLinePersonalInfo",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxLinePersonalInfo.setDefaultUnit(voltmx.flex.DP);
            flxLinePersonalInfo.add();
            flxPersonalInfo.add(lblPersonalInfo, flxLinePersonalInfo);
            var flxInternalExpo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInternalExpo",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "10%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInternalExpo.setDefaultUnit(voltmx.flex.DP);
            var lblIntrnalExpo = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblIntrnalExpo",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Internal Exposure",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInternalLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxInternalLine",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInternalLine.setDefaultUnit(voltmx.flex.DP);
            flxInternalLine.add();
            flxInternalExpo.add(lblIntrnalExpo, flxInternalLine);
            var flxFixedAssets = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFixedAssets",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "8%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxFixedAssets.setDefaultUnit(voltmx.flex.DP);
            var lblFixedAssets = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblFixedAssets",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Fixed Assets",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFixedLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxFixedLine",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxFixedLine.setDefaultUnit(voltmx.flex.DP);
            flxFixedLine.add();
            flxFixedAssets.add(lblFixedAssets, flxFixedLine);
            var flxCollateral = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCollateral",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "6%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollateral.setDefaultUnit(voltmx.flex.DP);
            var lblCollateral = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblCollateral",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Collateral",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCollateralLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxCollateralLine",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollateralLine.setDefaultUnit(voltmx.flex.DP);
            flxCollateralLine.add();
            flxCollateral.add(lblCollateral, flxCollateralLine);
            var flxRiskRating = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRiskRating",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "7%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskRating.setDefaultUnit(voltmx.flex.DP);
            var lblRiskRating = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblRiskRating",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Risk Rating",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRiskRatingLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxRiskRatingLine",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskRatingLine.setDefaultUnit(voltmx.flex.DP);
            flxRiskRatingLine.add();
            flxRiskRating.add(lblRiskRating, flxRiskRatingLine);
            var flxInsuranceAss = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInsuranceAss",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "13%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsuranceAss.setDefaultUnit(voltmx.flex.DP);
            var lblInsuranceAss = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblInsuranceAss",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Insurance / Assurance",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInsuranceLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxInsuranceLine",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsuranceLine.setDefaultUnit(voltmx.flex.DP);
            flxInsuranceLine.add();
            flxInsuranceAss.add(lblInsuranceAss, flxInsuranceLine);
            var flxScoredLendingInsi = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxScoredLendingInsi",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "13%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxScoredLendingInsi.setDefaultUnit(voltmx.flex.DP);
            var lblScoredLendingInsights = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblScoredLendingInsights",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Scored Lending Insights",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLineScoredLend = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxLineScoredLend",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxLineScoredLend.setDefaultUnit(voltmx.flex.DP);
            flxLineScoredLend.add();
            flxScoredLendingInsi.add(lblScoredLendingInsights, flxLineScoredLend);
            var flxEconomicGrowth = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxEconomicGrowth",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "13%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEconomicGrowth.setDefaultUnit(voltmx.flex.DP);
            var lblEconomicGrowth = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblEconomicGrowth",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Economic Group",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLineEconomicGrowth = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxLineEconomicGrowth",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxLineEconomicGrowth.setDefaultUnit(voltmx.flex.DP);
            flxLineEconomicGrowth.add();
            flxEconomicGrowth.add(lblEconomicGrowth, flxLineEconomicGrowth);
            flxTabs.add(flxContactInfo, flxOperationalInfo, flxPersonalInfo, flxInternalExpo, flxFixedAssets, flxCollateral, flxRiskRating, flxInsuranceAss, flxScoredLendingInsi, flxEconomicGrowth);
            var flxSegData = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxSegData",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_HORIZONTAL,
                "skin": "sknFlxSrcWhiteBGBlckBrdr",
                "top": "16dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxSegData.setDefaultUnit(voltmx.flex.DP);
            var flxSegHdr = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSegHdr",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBGEDF5FF",
                "top": "0dp",
                "width": "1600dp",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegHdr.setDefaultUnit(voltmx.flex.DP);
            var lblAcctTypeHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblAcctTypeHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Account Type",
                "width": "5%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAcctNoHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblAcctNoHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Account No",
                "width": "5%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBRIHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblBRIHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "BRI",
                "width": "2%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutStandingBalHDr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblOutStandingBalHDr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "width": "6%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInstallHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblInstallHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Installement",
                "width": "5%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblArrearsHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblArrearsHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Arrears Excess",
                "width": "7%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblAmountHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Amount Due",
                "width": "5%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoanAmtHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblLoanAmtHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Original Loan Amount",
                "width": "6%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOriginalLmtHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblOriginalLmtHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Original Limit",
                "width": "5.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCorrentLmtHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblCorrentLmtHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Current Limit",
                "width": "5.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInterestHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblInterestHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Interest Rate",
                "width": "3%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOrignateHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblOrignateHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Origination Date",
                "width": "5%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOrignalTermHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblOrignalTermHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Original Term",
                "width": "5%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRemainingTermHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblRemainingTermHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Remaining Term",
                "width": "5%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegHdr.add(lblAcctTypeHdr, lblAcctNoHdr, lblBRIHdr, lblOutStandingBalHDr, lblInstallHdr, lblArrearsHdr, lblAmountHdr, lblLoanAmtHdr, lblOriginalLmtHdr, lblCorrentLmtHdr, lblInterestHdr, lblOrignateHdr, lblOrignalTermHdr, lblRemainingTermHdr);
            var flxSeg = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxSeg",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "1600dp",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeg.setDefaultUnit(voltmx.flex.DP);
            var segInternalExposure = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOriginalTerm": "Label",
                    "lblOriginationDate": "Label",
                    "lblOutstandingBal": "Label",
                    "lblRemTerm": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOriginalTerm": "Label",
                    "lblOriginationDate": "Label",
                    "lblOutstandingBal": "Label",
                    "lblRemTerm": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOriginalTerm": "Label",
                    "lblOriginationDate": "Label",
                    "lblOutstandingBal": "Label",
                    "lblRemTerm": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOriginalTerm": "Label",
                    "lblOriginationDate": "Label",
                    "lblOutstandingBal": "Label",
                    "lblRemTerm": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOriginalTerm": "Label",
                    "lblOriginationDate": "Label",
                    "lblOutstandingBal": "Label",
                    "lblRemTerm": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOriginalTerm": "Label",
                    "lblOriginationDate": "Label",
                    "lblOutstandingBal": "Label",
                    "lblRemTerm": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOriginalTerm": "Label",
                    "lblOriginationDate": "Label",
                    "lblOutstandingBal": "Label",
                    "lblRemTerm": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOriginalTerm": "Label",
                    "lblOriginationDate": "Label",
                    "lblOutstandingBal": "Label",
                    "lblRemTerm": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOriginalTerm": "Label",
                    "lblOriginationDate": "Label",
                    "lblOutstandingBal": "Label",
                    "lblRemTerm": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOriginalTerm": "Label",
                    "lblOriginationDate": "Label",
                    "lblOutstandingBal": "Label",
                    "lblRemTerm": "Label"
                }],
                "groupCells": false,
                "id": "segInternalExposure",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "SBCommon",
                    "friendlyName": "flxRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxRow": "flxRow",
                    "lblAccNo": "lblAccNo",
                    "lblAcctType": "lblAcctType",
                    "lblAmountDue": "lblAmountDue",
                    "lblArrearsExcess": "lblArrearsExcess",
                    "lblBRI": "lblBRI",
                    "lblCurrentLimit": "lblCurrentLimit",
                    "lblInstalment": "lblInstalment",
                    "lblInterestRate": "lblInterestRate",
                    "lblOrgLimit": "lblOrgLimit",
                    "lblOrgLoanAmt": "lblOrgLoanAmt",
                    "lblOriginalTerm": "lblOriginalTerm",
                    "lblOriginationDate": "lblOriginationDate",
                    "lblOutstandingBal": "lblOutstandingBal",
                    "lblRemTerm": "lblRemTerm"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeg.add(segInternalExposure);
            flxSegData.add(flxSegHdr, flxSeg);
            var flxChart = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "400dp",
                "id": "flxChart",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "34dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxChart.setDefaultUnit(voltmx.flex.DP);
            var SubHdr1 = new com.hcl.subHdr.SubHdr({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "45dp",
                "id": "SubHdr1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": "0dp",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "SubHdr": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "lblSubHdr": {
                        "text": "Chart"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var linechart = new com.konymp.linechart({
                "height": "100%",
                "id": "linechart",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "Customer360",
                "viewType": "linechart",
                "overrides": {
                    "linechart": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            linechart.chartTitle = "Line Chart";
            linechart.chartData = {
                "data": [{
                    "dataVal": "9",
                    "lblName": "data1"
                }, {
                    "dataVal": "2",
                    "lblName": "data2"
                }, {
                    "dataVal": "5",
                    "lblName": "data3"
                }, {
                    "dataVal": "12",
                    "lblName": "data4"
                }],
                "schema": [{
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Label Name",
                    "columnHeaderType": "text",
                    "columnID": "lblName",
                    "columnOnClick": null,
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "f1a80a1c509a45d0ad84b3097d1e8cb7"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Value",
                    "columnHeaderType": "text",
                    "columnID": "dataVal",
                    "columnOnClick": null,
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "c4dc7111a5f24c0da4cf8236ddad5233"
                }]
            };
            linechart.enableGrid = true;
            linechart.xAxisTitle = "x-axis";
            linechart.yAxisTitle = "y-axis";
            linechart.lowValue = "0";
            linechart.titleFontColor = "#000000";
            linechart.enableGridAnimation = true;
            linechart.titleFontSize = "12";
            linechart.highValue = "40";
            linechart.lineColor = "#1B9ED9";
            linechart.bgColor = "#FFFFFF";
            linechart.enableChartAnimation = true;
            linechart.enableStaticPreview = true;
            flxChart.add(SubHdr1, linechart);
            var flxCollaInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "16dp",
                "clipBounds": false,
                "id": "flxCollaInfo",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollaInfo.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0d30e5986678c4a = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "FlexContainer0d30e5986678c4a",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0d30e5986678c4a.setDefaultUnit(voltmx.flex.DP);
            var flxCollData1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "flxCollData1",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "48%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [16, 0, 16, 16],
                "paddingInPixel": true
            }, {});
            flxCollData1.setDefaultUnit(voltmx.flex.DP);
            var flxCollType = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCollType",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollType.setDefaultUnit(voltmx.flex.DP);
            var CollateralType = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CollateralType",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Collateral Type / Value"
                    },
                    "lblDetailValue": {
                        "text": "Surityship Partial Liability",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCollType.add(CollateralType);
            var flxLinkedAcct = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLinkedAcct",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxLinkedAcct.setDefaultUnit(voltmx.flex.DP);
            var LinkeAcct = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "LinkeAcct",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Linked Account"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLinkedAcct.add(LinkeAcct);
            var flxSurrenderValue = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSurrenderValue",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSurrenderValue.setDefaultUnit(voltmx.flex.DP);
            var SurrenderValue = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "SurrenderValue",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Surrender Value"
                    },
                    "lblDetailValue": {
                        "text": "R 35K"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSurrenderValue.add(SurrenderValue);
            flxCollData1.add(flxCollType, flxLinkedAcct, flxSurrenderValue);
            var CopyflxCollData0da6eebb917a84b = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "CopyflxCollData0da6eebb917a84b",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "4%",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "48%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [16, 0, 16, 16],
                "paddingInPixel": true
            }, {});
            CopyflxCollData0da6eebb917a84b.setDefaultUnit(voltmx.flex.DP);
            var CopyflxCollType0d72fb571a91e46 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxCollType0d72fb571a91e46",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCollType0d72fb571a91e46.setDefaultUnit(voltmx.flex.DP);
            var CopyCollateralType0c0da5ba4346d44 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCollateralType0c0da5ba4346d44",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Collateral Type / Value"
                    },
                    "lblDetailValue": {
                        "text": "Surityship Partial Liability",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCollType0d72fb571a91e46.add(CopyCollateralType0c0da5ba4346d44);
            var CopyflxLinkedAcct0fb20329bf6b446 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxLinkedAcct0fb20329bf6b446",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxLinkedAcct0fb20329bf6b446.setDefaultUnit(voltmx.flex.DP);
            var CopyLinkeAcct0df9fdc6fb25146 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyLinkeAcct0df9fdc6fb25146",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Linked Account"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxLinkedAcct0fb20329bf6b446.add(CopyLinkeAcct0df9fdc6fb25146);
            var CopyflxSurrenderValue0i16848fc57c847 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxSurrenderValue0i16848fc57c847",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSurrenderValue0i16848fc57c847.setDefaultUnit(voltmx.flex.DP);
            var CopySurrenderValue0ebf0965aa25740 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopySurrenderValue0ebf0965aa25740",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Surrender Value"
                    },
                    "lblDetailValue": {
                        "text": "R 35K"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxSurrenderValue0i16848fc57c847.add(CopySurrenderValue0ebf0965aa25740);
            CopyflxCollData0da6eebb917a84b.add(CopyflxCollType0d72fb571a91e46, CopyflxLinkedAcct0fb20329bf6b446, CopyflxSurrenderValue0i16848fc57c847);
            FlexContainer0d30e5986678c4a.add(flxCollData1, CopyflxCollData0da6eebb917a84b);
            var CopyflxCollData0aa9289046da44e = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "CopyflxCollData0aa9289046da44e",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [16, 0, 16, 16],
                "paddingInPixel": true
            }, {});
            CopyflxCollData0aa9289046da44e.setDefaultUnit(voltmx.flex.DP);
            var CopyflxCollType0b80cfa2e6dc240 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxCollType0b80cfa2e6dc240",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCollType0b80cfa2e6dc240.setDefaultUnit(voltmx.flex.DP);
            var CopyCollateralType0dbd8532d739946 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCollateralType0dbd8532d739946",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Collateral Type / Value"
                    },
                    "lblDetailValue": {
                        "text": "Surityship Partial Liability",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCollType0b80cfa2e6dc240.add(CopyCollateralType0dbd8532d739946);
            var CopyflxLinkedAcct0fbd34e3b35554d = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxLinkedAcct0fbd34e3b35554d",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxLinkedAcct0fbd34e3b35554d.setDefaultUnit(voltmx.flex.DP);
            var CopyLinkeAcct0c9ef530a37af4f = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyLinkeAcct0c9ef530a37af4f",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Linked Account"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxLinkedAcct0fbd34e3b35554d.add(CopyLinkeAcct0c9ef530a37af4f);
            var CopyflxSurrenderValue0j2b11a7c74bf45 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxSurrenderValue0j2b11a7c74bf45",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSurrenderValue0j2b11a7c74bf45.setDefaultUnit(voltmx.flex.DP);
            var CopySurrenderValue0c62d8b967ddd43 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopySurrenderValue0c62d8b967ddd43",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Surrender Value"
                    },
                    "lblDetailValue": {
                        "text": "R 35K"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxSurrenderValue0j2b11a7c74bf45.add(CopySurrenderValue0c62d8b967ddd43);
            CopyflxCollData0aa9289046da44e.add(CopyflxCollType0b80cfa2e6dc240, CopyflxLinkedAcct0fbd34e3b35554d, CopyflxSurrenderValue0j2b11a7c74bf45);
            var CopyflxCollData0d8ceceea052c48 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "CopyflxCollData0d8ceceea052c48",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [16, 0, 16, 16],
                "paddingInPixel": true
            }, {});
            CopyflxCollData0d8ceceea052c48.setDefaultUnit(voltmx.flex.DP);
            var CopyflxCollType0bfa00fe0d9724c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxCollType0bfa00fe0d9724c",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCollType0bfa00fe0d9724c.setDefaultUnit(voltmx.flex.DP);
            var CopyCollateralType0eca11d9ecebf4c = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCollateralType0eca11d9ecebf4c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Collateral Type / Value"
                    },
                    "lblDetailValue": {
                        "text": "Surityship Partial Liability",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCollType0bfa00fe0d9724c.add(CopyCollateralType0eca11d9ecebf4c);
            var CopyflxLinkedAcct0dd9257b658d740 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxLinkedAcct0dd9257b658d740",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxLinkedAcct0dd9257b658d740.setDefaultUnit(voltmx.flex.DP);
            var CopyLinkeAcct0cd84883d7da848 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyLinkeAcct0cd84883d7da848",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Linked Account"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxLinkedAcct0dd9257b658d740.add(CopyLinkeAcct0cd84883d7da848);
            var CopyflxSurrenderValue0g81b3453b2bd47 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxSurrenderValue0g81b3453b2bd47",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSurrenderValue0g81b3453b2bd47.setDefaultUnit(voltmx.flex.DP);
            var CopySurrenderValue0hc8da927997147 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopySurrenderValue0hc8da927997147",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Surrender Value"
                    },
                    "lblDetailValue": {
                        "text": "R 35K"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxSurrenderValue0g81b3453b2bd47.add(CopySurrenderValue0hc8da927997147);
            CopyflxCollData0d8ceceea052c48.add(CopyflxCollType0bfa00fe0d9724c, CopyflxLinkedAcct0dd9257b658d740, CopyflxSurrenderValue0g81b3453b2bd47);
            var CopyflxCollData0bc73e50e178c42 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "CopyflxCollData0bc73e50e178c42",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [16, 0, 16, 16],
                "paddingInPixel": true
            }, {});
            CopyflxCollData0bc73e50e178c42.setDefaultUnit(voltmx.flex.DP);
            var CopyflxCollType0dbc6dd0c5c5345 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxCollType0dbc6dd0c5c5345",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCollType0dbc6dd0c5c5345.setDefaultUnit(voltmx.flex.DP);
            var CopyCollateralType0bbfffbf96c9042 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCollateralType0bbfffbf96c9042",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Collateral Type / Value"
                    },
                    "lblDetailValue": {
                        "text": "Surityship Partial Liability",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCollType0dbc6dd0c5c5345.add(CopyCollateralType0bbfffbf96c9042);
            var CopyflxLinkedAcct0id46d1885b2840 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxLinkedAcct0id46d1885b2840",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxLinkedAcct0id46d1885b2840.setDefaultUnit(voltmx.flex.DP);
            var CopyLinkeAcct0jea18c9afb8d49 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyLinkeAcct0jea18c9afb8d49",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Linked Account"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxLinkedAcct0id46d1885b2840.add(CopyLinkeAcct0jea18c9afb8d49);
            var CopyflxSurrenderValue0ac30c44a072449 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxSurrenderValue0ac30c44a072449",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSurrenderValue0ac30c44a072449.setDefaultUnit(voltmx.flex.DP);
            var CopySurrenderValue0bb7e4d15b41d47 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopySurrenderValue0bb7e4d15b41d47",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Surrender Value"
                    },
                    "lblDetailValue": {
                        "text": "R 35K"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxSurrenderValue0ac30c44a072449.add(CopySurrenderValue0bb7e4d15b41d47);
            CopyflxCollData0bc73e50e178c42.add(CopyflxCollType0dbc6dd0c5c5345, CopyflxLinkedAcct0id46d1885b2840, CopyflxSurrenderValue0ac30c44a072449);
            flxCollaInfo.add(FlexContainer0d30e5986678c4a, CopyflxCollData0aa9289046da44e, CopyflxCollData0d8ceceea052c48, CopyflxCollData0bc73e50e178c42);
            var flxInsuranceInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInsuranceInfo",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsuranceInfo.setDefaultUnit(voltmx.flex.DP);
            var CopyflxCollData0d8cfd7e598b043 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "CopyflxCollData0d8cfd7e598b043",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [16, 0, 16, 16],
                "paddingInPixel": true
            }, {});
            CopyflxCollData0d8cfd7e598b043.setDefaultUnit(voltmx.flex.DP);
            var CopyflxCollType0e8cce0e160e84d = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxCollType0e8cce0e160e84d",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCollType0e8cce0e160e84d.setDefaultUnit(voltmx.flex.DP);
            var CopyCollateralType0f124115cfe6e4f = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCollateralType0f124115cfe6e4f",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "isVisible": false,
                        "text": "SBIB"
                    },
                    "lblDetailValue": {
                        "text": "SBIB",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCollType0e8cce0e160e84d.add(CopyCollateralType0f124115cfe6e4f);
            var CopyflxLinkedAcct0f4b0a06c59544d = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxLinkedAcct0f4b0a06c59544d",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxLinkedAcct0f4b0a06c59544d.setDefaultUnit(voltmx.flex.DP);
            var CopyLinkeAcct0cc93bd5adfef4c = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyLinkeAcct0cc93bd5adfef4c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "57687234812934"
                    },
                    "lblDetailValue": {
                        "text": "DisabilityCover"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxLinkedAcct0f4b0a06c59544d.add(CopyLinkeAcct0cc93bd5adfef4c);
            var CopyflxSurrenderValue0ca79a61bddd743 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxSurrenderValue0ca79a61bddd743",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSurrenderValue0ca79a61bddd743.setDefaultUnit(voltmx.flex.DP);
            var CopySurrenderValue0afc66f421bb44a = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopySurrenderValue0afc66f421bb44a",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Monthly Premium"
                    },
                    "lblDetailValue": {
                        "text": "R 350"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxSurrenderValue0ca79a61bddd743.add(CopySurrenderValue0afc66f421bb44a);
            CopyflxCollData0d8cfd7e598b043.add(CopyflxCollType0e8cce0e160e84d, CopyflxLinkedAcct0f4b0a06c59544d, CopyflxSurrenderValue0ca79a61bddd743);
            var CopyflxCollData0ffa1aa8d2e7e45 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "CopyflxCollData0ffa1aa8d2e7e45",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [16, 0, 16, 16],
                "paddingInPixel": true
            }, {});
            CopyflxCollData0ffa1aa8d2e7e45.setDefaultUnit(voltmx.flex.DP);
            var CopyflxCollType0d37fc1b9559141 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxCollType0d37fc1b9559141",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCollType0d37fc1b9559141.setDefaultUnit(voltmx.flex.DP);
            var CopyCollateralType0cd6f3a4995b943 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCollateralType0cd6f3a4995b943",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "isVisible": false,
                        "text": "SBIB"
                    },
                    "lblDetailValue": {
                        "text": "Old Mutual",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCollType0d37fc1b9559141.add(CopyCollateralType0cd6f3a4995b943);
            var CopyflxLinkedAcct0j0a2d71e22294f = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxLinkedAcct0j0a2d71e22294f",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxLinkedAcct0j0a2d71e22294f.setDefaultUnit(voltmx.flex.DP);
            var CopyLinkeAcct0da2e01e5fe6b4c = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyLinkeAcct0da2e01e5fe6b4c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "57687234812934"
                    },
                    "lblDetailValue": {
                        "text": "DisabilityCover"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxLinkedAcct0j0a2d71e22294f.add(CopyLinkeAcct0da2e01e5fe6b4c);
            var CopyflxSurrenderValue0d16b6400677d44 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxSurrenderValue0d16b6400677d44",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSurrenderValue0d16b6400677d44.setDefaultUnit(voltmx.flex.DP);
            var CopySurrenderValue0bd3f3f677bd442 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopySurrenderValue0bd3f3f677bd442",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Monthly Premium"
                    },
                    "lblDetailValue": {
                        "text": "R 350"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxSurrenderValue0d16b6400677d44.add(CopySurrenderValue0bd3f3f677bd442);
            CopyflxCollData0ffa1aa8d2e7e45.add(CopyflxCollType0d37fc1b9559141, CopyflxLinkedAcct0j0a2d71e22294f, CopyflxSurrenderValue0d16b6400677d44);
            var CopyflxCollData0a6b9be56bad546 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "16dp",
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "CopyflxCollData0a6b9be56bad546",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [16, 0, 16, 16],
                "paddingInPixel": true
            }, {});
            CopyflxCollData0a6b9be56bad546.setDefaultUnit(voltmx.flex.DP);
            var CopyflxCollType0cd16c86ee49b48 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxCollType0cd16c86ee49b48",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCollType0cd16c86ee49b48.setDefaultUnit(voltmx.flex.DP);
            var CopyCollateralType0hc7ba7b34a0c4d = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCollateralType0hc7ba7b34a0c4d",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "isVisible": false,
                        "text": "SBIB"
                    },
                    "lblDetailValue": {
                        "text": "SBIB",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCollType0cd16c86ee49b48.add(CopyCollateralType0hc7ba7b34a0c4d);
            var CopyflxLinkedAcct0bba69a7d139740 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxLinkedAcct0bba69a7d139740",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxLinkedAcct0bba69a7d139740.setDefaultUnit(voltmx.flex.DP);
            var CopyLinkeAcct0j9a21367001345 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyLinkeAcct0j9a21367001345",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "57687234812934"
                    },
                    "lblDetailValue": {
                        "text": "DisabilityCover"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxLinkedAcct0bba69a7d139740.add(CopyLinkeAcct0j9a21367001345);
            var CopyflxSurrenderValue0a3a7abf2911044 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxSurrenderValue0a3a7abf2911044",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSurrenderValue0a3a7abf2911044.setDefaultUnit(voltmx.flex.DP);
            var CopySurrenderValue0d20cf40857d744 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopySurrenderValue0d20cf40857d744",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Monthly Premium"
                    },
                    "lblDetailValue": {
                        "text": "R 350"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxSurrenderValue0a3a7abf2911044.add(CopySurrenderValue0d20cf40857d744);
            CopyflxCollData0a6b9be56bad546.add(CopyflxCollType0cd16c86ee49b48, CopyflxLinkedAcct0bba69a7d139740, CopyflxSurrenderValue0a3a7abf2911044);
            flxInsuranceInfo.add(CopyflxCollData0d8cfd7e598b043, CopyflxCollData0ffa1aa8d2e7e45, CopyflxCollData0a6b9be56bad546);
            var flxOpInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "16dp",
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxOpInfo",
                "isVisible": false,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [12, 8, 12, 8],
                "paddingInPixel": true
            }, {});
            flxOpInfo.setDefaultUnit(voltmx.flex.DP);
            var flxOwnerShip = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxOwnerShip",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxOwnerShip.setDefaultUnit(voltmx.flex.DP);
            var OwnerShip = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "OwnerShip",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Ownership (Shareholders & % shareholding)"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "Anthea Paula Turwome 40% \nArnold Patrick Samson Turwomwe 60%\ncasdasd sdcsad\n"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxOwnerShip.add(OwnerShip);
            var flxWomenOwned = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxWomenOwned",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxWomenOwned.setDefaultUnit(voltmx.flex.DP);
            var lblWomenOwned = new voltmx.ui.Label({
                "id": "lblWomenOwned",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Women Owned",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyrdoProfileType0b03651aa0c6d40 = new voltmx.ui.RadioButtonGroup({
                "id": "CopyrdoProfileType0b03651aa0c6d40",
                "isVisible": true,
                "masterData": [
                    ["No", "No"],
                    ["Yes", "Yes"]
                ],
                "selectedKey": "No",
                "skin": "slRadioButtonGroup",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWomenOwned.add(lblWomenOwned, CopyrdoProfileType0b03651aa0c6d40);
            var flxDescBussiness = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDescBussiness",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxDescBussiness.setDefaultUnit(voltmx.flex.DP);
            var DescriptionBusiness = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "DescriptionBusiness",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Description Of Business "
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "Dealers in Marketing and supply of promotional materials and other general supplies\n"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDescBussiness.add(DescriptionBusiness);
            var flxManagement = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxManagement",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxManagement.setDefaultUnit(voltmx.flex.DP);
            var Management = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "Management",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Management"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "Managment is composed of Benon Mascot with seventeen years of experience in business and banking professional\ncharged key Business decisions and sourcing finances.\n"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxManagement.add(Management);
            var flxNatureOfBuss = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNatureOfBuss",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxNatureOfBuss.setDefaultUnit(voltmx.flex.DP);
            var NatureOfBussiness = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "NatureOfBussiness",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Nature Of Business"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "80/20 Marketing Ltd 80/20 Marketing Ltd for the past 6 years has been operating as a supplier for branded promotional items and also a service provider for PR Communications services with its clientele ranging from NGOs, Government and also the private sector. Today, the company has a partnership with leading South African distributor of Promotional Items called BARON and also has connections with suppliers of high quality items from China as well. The company is pre-qualified with companies like UDB, Bank of Africa, URA, ICEA, MTN Uganda, TOTALENERGIES, etc. They also look at targeting our existing clients who have repeatedly ordered from them which tells that they satisfied with their items & services and would place orders over & over again J"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxNatureOfBuss.add(NatureOfBussiness);
            var flxPrincipalProductRange = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPrincipalProductRange",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrincipalProductRange.setDefaultUnit(voltmx.flex.DP);
            var PrincipalProductRange = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "PrincipalProductRange",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Principal Product Range"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "TE Branded Promotional Items (Apparel, Drinkware, Outdoor advertising material, Business Gifts) D Office Branding • Advertising • PR Communications • Digital Marketing Ltd J"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPrincipalProductRange.add(PrincipalProductRange);
            var flxPPMarketPlace = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPPMarketPlace",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPPMarketPlace.setDefaultUnit(voltmx.flex.DP);
            var PPMarketPlace = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "PPMarketPlace",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Position of Principal product in market place"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "The principal product of 80/20 Marketing Ltd is Branded Promotional Items. The client has positioned themselves as suppliers of high quality promotional items at affordable prices and this has enabled us serve and retain big brands like MT Uganda, TOTAL Energies, ICEA Insurance, AAR Insurance etc."
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPPMarketPlace.add(PPMarketPlace);
            var flxCapitalLabIntensity = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCapitalLabIntensity",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCapitalLabIntensity.setDefaultUnit(voltmx.flex.DP);
            var CapitalLabourIntensity = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CapitalLabourIntensity",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Capital Labour Intensity"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "80/20 Marketing Ltd runs a highly capital intensive operation and need massive amounts of capital expenditure to fulfill client's orders. Some clients order 1,000s of items with zero deposits meaning the budget is met by the company which has to wait 30-60 days to get payment. The Client employs labour but they usually come in to finished products so their main role is to do deliveries, sales and after sales\n"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCapitalLabIntensity.add(CapitalLabourIntensity);
            var flxDistribution = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDistribution",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxDistribution.setDefaultUnit(voltmx.flex.DP);
            var Distribution = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "Distribution",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Distribution"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "80/20 Marketing receives its goods through Entebbe Airport by air freight for goods coming from South Africa and China and the East Africa Bond in Namanve for goods coming from China. The goods are kept in their store in Bwebaija on Entebbe road. Goods that are urgently needed by clients are normally moved from the bond, to our office premises for inspection and taken to client's stores.\n"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDistribution.add(Distribution);
            var flxGeographicLoc = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGeographicLoc",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxGeographicLoc.setDefaultUnit(voltmx.flex.DP);
            var GeographicLoc = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "GeographicLoc",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Geographic Location"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "80/20 Marketing is located at Plot 20, Bukoto Street - Kampala where it has had its premises for the past 6\nyears.\n"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxGeographicLoc.add(GeographicLoc);
            var flxMainSuppCred = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainSuppCred",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainSuppCred.setDefaultUnit(voltmx.flex.DP);
            var MainSuppCred = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "MainSuppCred",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Main suppliers/creditors"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "BARRON South Africa\nAMROD South Africa\nMekea Import and\nExport Company Ltd Visible Investments\n"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMainSuppCred.add(MainSuppCred);
            var flxMainCustDeb = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainCustDeb",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainCustDeb.setDefaultUnit(voltmx.flex.DP);
            var MainCustSupDeb = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "MainCustSupDeb",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Main customers/debtors spread"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "MTN Uganda\nICEA Insurance\nAAR Insurance\nTotal Energies\nUganda Wildlife Authority\nWorld Health Organisation"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMainCustDeb.add(MainCustSupDeb);
            var CopyflxWomenOwned0f319c5389a644c = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxWomenOwned0f319c5389a644c",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxWomenOwned0f319c5389a644c.setDefaultUnit(voltmx.flex.DP);
            var CopylblWomenOwned0cac3484ab35744 = new voltmx.ui.Label({
                "id": "CopylblWomenOwned0cac3484ab35744",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Is the primary source of repayment derived from commercial property activities?",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyrdoProfileType0fb870aa1562842 = new voltmx.ui.RadioButtonGroup({
                "id": "CopyrdoProfileType0fb870aa1562842",
                "isVisible": true,
                "masterData": [
                    ["No", "No"],
                    ["Yes", "Yes"]
                ],
                "selectedKey": "No",
                "skin": "slRadioButtonGroup",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxWomenOwned0f319c5389a644c.add(CopylblWomenOwned0cac3484ab35744, CopyrdoProfileType0fb870aa1562842);
            var CopyflxWomenOwned0c6b1659c74eb49 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxWomenOwned0c6b1659c74eb49",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxWomenOwned0c6b1659c74eb49.setDefaultUnit(voltmx.flex.DP);
            var CopylblWomenOwned0ab46757db1d34a = new voltmx.ui.Label({
                "id": "CopylblWomenOwned0ab46757db1d34a",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Is the purpose of the loan to acquire or finance a commercial property?",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyrdoProfileType0g094fe2a68ba49 = new voltmx.ui.RadioButtonGroup({
                "id": "CopyrdoProfileType0g094fe2a68ba49",
                "isVisible": true,
                "masterData": [
                    ["No", "No"],
                    ["Yes", "Yes"]
                ],
                "selectedKey": "No",
                "skin": "slRadioButtonGroup",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxWomenOwned0c6b1659c74eb49.add(CopylblWomenOwned0ab46757db1d34a, CopyrdoProfileType0g094fe2a68ba49);
            var CopyflxWomenOwned0dbf73110e7fe45 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxWomenOwned0dbf73110e7fe45",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxWomenOwned0dbf73110e7fe45.setDefaultUnit(voltmx.flex.DP);
            var CopylblWomenOwned0dc6bdd209d7547 = new voltmx.ui.Label({
                "id": "CopylblWomenOwned0dc6bdd209d7547",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Is the cash flow generated by the property (e.g. rent or sale of property), the main source of loan repayment?",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyrdoProfileType0gf58975701f54e = new voltmx.ui.RadioButtonGroup({
                "id": "CopyrdoProfileType0gf58975701f54e",
                "isVisible": true,
                "masterData": [
                    ["No", "No"],
                    ["Yes", "Yes"]
                ],
                "selectedKey": "No",
                "skin": "slRadioButtonGroup",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxWomenOwned0dbf73110e7fe45.add(CopylblWomenOwned0dc6bdd209d7547, CopyrdoProfileType0gf58975701f54e);
            var flxLastSiteVisit = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLastSiteVisit",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 3,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxLastSiteVisit.setDefaultUnit(voltmx.flex.DP);
            var LastVisitSite = new voltmx.ui.Label({
                "id": "LastVisitSite",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Date of last site visit",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var calLastVisitSite = new voltmx.ui.Calendar({
                "calendarIcon": "icon_cal.png",
                "dateComponents": [9, 9, 2015],
                "dateFormat": "dd/MM/yyyy",
                "day": 9,
                "formattedDate": "09/09/2015",
                "height": "40dp",
                "hour": 0,
                "id": "calLastVisitSite",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "month": 9,
                "seconds": 0,
                "skin": "sknSBCalender",
                "top": "5dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "year": 2015,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [16, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "noOfMonths": 1
            });
            flxLastSiteVisit.add(LastVisitSite, calLastVisitSite);
            var flxLastDept = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLastDept",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 3,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxLastDept.setDefaultUnit(voltmx.flex.DP);
            var LastDept = new voltmx.ui.Label({
                "id": "LastDept",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Date of last deposit",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var calLastDept = new voltmx.ui.Calendar({
                "calendarIcon": "icon_cal.png",
                "dateComponents": [9, 9, 2015],
                "dateFormat": "dd/MM/yyyy",
                "day": 9,
                "formattedDate": "09/09/2015",
                "height": "40dp",
                "hour": 0,
                "id": "calLastDept",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "month": 9,
                "seconds": 0,
                "skin": "sknSBCalender",
                "top": "5dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "year": 2015,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [16, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "noOfMonths": 1
            });
            flxLastDept.add(LastDept, calLastDept);
            var flxDirExec = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDirExec",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxDirExec.setDefaultUnit(voltmx.flex.DP);
            var DirExec = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "DirExec",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Directors - Executive"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "Benon Mascot\nAnthea Turwomwe\nArnold Turwomwe\n"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDirExec.add(DirExec);
            var flxSBGAssoc = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSBGAssoc",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 3,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSBGAssoc.setDefaultUnit(voltmx.flex.DP);
            var SBGAssociate = new voltmx.ui.Label({
                "id": "SBGAssociate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Banked with SBG since",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var calSBGAssoc = new voltmx.ui.Calendar({
                "calendarIcon": "icon_cal.png",
                "dateComponents": [9, 9, 2015],
                "dateFormat": "dd/MM/yyyy",
                "day": 9,
                "formattedDate": "09/09/2015",
                "height": "40dp",
                "hour": 0,
                "id": "calSBGAssoc",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "month": 9,
                "seconds": 0,
                "skin": "sknSBCalender",
                "top": "5dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "year": 2015,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [16, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "noOfMonths": 1
            });
            flxSBGAssoc.add(SBGAssociate, calSBGAssoc);
            var flxFinancialYrEnd = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFinancialYrEnd",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 3,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxFinancialYrEnd.setDefaultUnit(voltmx.flex.DP);
            var FinancialYrEnd = new com.hcl.lblList.LabelList({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "FinancialYrEnd",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "flxDropDwnList": {
                        "height": "30dp",
                        "right": "3dp",
                        "top": "3dp",
                        "width": "30dp"
                    },
                    "imgDropDwn": {
                        "height": "30dp",
                        "src": "icon_dropdwn.png",
                        "top": "0dp",
                        "width": "30dp"
                    },
                    "lblDetail": {
                        "text": "Financial Year End"
                    },
                    "listData": {
                        "masterData": [
                            ["6", "June"]
                        ],
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFinancialYrEnd.add(FinancialYrEnd);
            var flxDirNonExec = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDirNonExec",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxDirNonExec.setDefaultUnit(voltmx.flex.DP);
            var NonExecutive = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "NonExecutive",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Directors - Non-executive"
                    },
                    "txtArea": {
                        "height": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDirNonExec.add(NonExecutive);
            var flxCompetitors = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCompetitors",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCompetitors.setDefaultUnit(voltmx.flex.DP);
            var Competitors = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "Competitors",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Competitors"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "Rocket Products Ltd\nJude Colour Solutions\nClear Media"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCompetitors.add(Competitors);
            var flxAuditor = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAuditor",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxAuditor.setDefaultUnit(voltmx.flex.DP);
            var Auditor = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "Auditor",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Auditor"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "PANRANK & Company Plot 40 Bombo Road, Kampala"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAuditor.add(Auditor);
            var flxAcctHis = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcctHis",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcctHis.setDefaultUnit(voltmx.flex.DP);
            var AccHistory = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "AccHistory",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Account History"
                    },
                    "txtArea": {
                        "height": "100%",
                        "text": "Customer opened an account 9030019723797 on the 21/12/2021 domiciled at Forest Mall branch\n"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAcctHis.add(AccHistory);
            flxOpInfo.add(flxOwnerShip, flxWomenOwned, flxDescBussiness, flxManagement, flxNatureOfBuss, flxPrincipalProductRange, flxPPMarketPlace, flxCapitalLabIntensity, flxDistribution, flxGeographicLoc, flxMainSuppCred, flxMainCustDeb, CopyflxWomenOwned0f319c5389a644c, CopyflxWomenOwned0c6b1659c74eb49, CopyflxWomenOwned0dbf73110e7fe45, flxLastSiteVisit, flxLastDept, flxDirExec, flxSBGAssoc, flxFinancialYrEnd, flxDirNonExec, flxCompetitors, flxAuditor, flxAcctHis);
            var flxRiskTypes = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRiskTypes",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskTypes.setDefaultUnit(voltmx.flex.DP);
            var btnRisk1 = new voltmx.ui.Button({
                "height": "40dp",
                "id": "btnRisk1",
                "isVisible": true,
                "skin": "sknBtnLeftHighLite",
                "text": "BRI",
                "width": "115dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRisk2 = new voltmx.ui.Button({
                "height": "40dp",
                "id": "btnRisk2",
                "isVisible": true,
                "left": "0",
                "skin": "sknBtnUnSelect",
                "text": "CRI",
                "top": "0",
                "width": "115dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRisk3 = new voltmx.ui.Button({
                "height": "40dp",
                "id": "btnRisk3",
                "isVisible": true,
                "left": "0",
                "skin": "sknBtnUnSelect",
                "text": "ERI",
                "top": "0",
                "width": "115dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRisk4 = new voltmx.ui.Button({
                "height": "40dp",
                "id": "btnRisk4",
                "isVisible": true,
                "left": "0",
                "skin": "sknBtnUnSelect",
                "text": "BBRS",
                "top": "0",
                "width": "115dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRisk5 = new voltmx.ui.Button({
                "height": "40dp",
                "id": "btnRisk5",
                "isVisible": true,
                "left": "0",
                "skin": "sknBtnRightUnSelect",
                "text": "CRS",
                "top": "0",
                "width": "115dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRiskTypes.add(btnRisk1, btnRisk2, btnRisk3, btnRisk4, btnRisk5);
            var flxRiskInsight = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "16dp",
                "clipBounds": false,
                "id": "flxRiskInsight",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "16dp",
                "width": "100%",
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskInsight.setDefaultUnit(voltmx.flex.DP);
            var flxRiskRate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "16dp",
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "height": "300dp",
                "id": "flxRiskRate",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskRate.setDefaultUnit(voltmx.flex.DP);
            var lblHdrRiskType = new voltmx.ui.Label({
                "id": "lblHdrRiskType",
                "isVisible": true,
                "left": "24dp",
                "skin": "sknLblHeading4Bold",
                "text": "Risk Rating - BRI",
                "top": "17dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RiskRateChart = new com.riskrating.chart.RiskRateChart({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "focusSkin": "slFFocusbox",
                "height": "250dp",
                "id": "RiskRateChart",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "48dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexGroup0f364368a6aa841": {
                        "height": "85%"
                    },
                    "RiskRateChart": {
                        "height": "250dp",
                        "top": "48dp",
                        "width": "50%"
                    },
                    "flxPin": {
                        "centerY": "92%"
                    },
                    "imgChart": {
                        "height": "100%",
                        "src": "icon_rating.png"
                    },
                    "imgPin": {
                        "bottom": "5dp",
                        "src": "icon_pin.png"
                    },
                    "lblHigh": {
                        "centerY": "22%"
                    },
                    "lblLow": {
                        "centerX": "82%",
                        "centerY": "77%"
                    },
                    "lblMedium": {
                        "centerX": "70%",
                        "centerY": "36%"
                    },
                    "lblSubStandard": {
                        "centerX": "18%",
                        "centerY": "74%"
                    },
                    "lblVeryHigh": {
                        "centerX": "30%",
                        "centerY": "36%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var FlexContainer0e954e1006a6642 = new voltmx.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "FlexContainer0e954e1006a6642",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "50%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "50dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0e954e1006a6642.setDefaultUnit(voltmx.flex.DP);
            var flxRiskFields = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRiskFields",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": 0,
                "width": "50%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskFields.setDefaultUnit(voltmx.flex.DP);
            var flxPD = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPD",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPD.setDefaultUnit(voltmx.flex.DP);
            var ProbabilityDefault = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "ProbabilityDefault",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Probability Of Default"
                    },
                    "lblDetailValue": {
                        "text": "12"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPD.add(ProbabilityDefault);
            var flxRatingScore = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRatingScore",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRatingScore.setDefaultUnit(voltmx.flex.DP);
            var RiskScoreGrade = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "RiskScoreGrade",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Rating Score"
                    },
                    "lblDetailValue": {
                        "text": "12"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRatingScore.add(RiskScoreGrade);
            var flxHide = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHide",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxHide.setDefaultUnit(voltmx.flex.DP);
            var hide = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "hide",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHide.add(hide);
            var flxRiskScoreLCY = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRiskScoreLCY",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskScoreLCY.setDefaultUnit(voltmx.flex.DP);
            var CopyRiskScoreGrade0eb3d7cc239f542 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyRiskScoreGrade0eb3d7cc239f542",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Risk Grade LCY"
                    },
                    "lblDetailValue": {
                        "text": "LCY"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRiskScoreLCY.add(CopyRiskScoreGrade0eb3d7cc239f542);
            var flxRiskScoreFCY = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRiskScoreFCY",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskScoreFCY.setDefaultUnit(voltmx.flex.DP);
            var CopyRiskScoreGrade0fa0a4b9ab6cd45 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyRiskScoreGrade0fa0a4b9ab6cd45",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Risk Grade FCY"
                    },
                    "lblDetailValue": {
                        "text": "FCY"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRiskScoreFCY.add(CopyRiskScoreGrade0fa0a4b9ab6cd45);
            flxRiskFields.add(flxPD, flxRatingScore, flxHide, flxRiskScoreLCY, flxRiskScoreFCY);
            var flxRiskReasons = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRiskReasons",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "50%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskReasons.setDefaultUnit(voltmx.flex.DP);
            var flxReason1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxReason1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxReason1.setDefaultUnit(voltmx.flex.DP);
            var CopyReason0e4a8784fb61849 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyReason0e4a8784fb61849",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Reason1"
                    },
                    "lblDetailValue": {
                        "text": "reason1"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxReason1.add(CopyReason0e4a8784fb61849);
            var flxReason2 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxReason2",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxReason2.setDefaultUnit(voltmx.flex.DP);
            var CopyReason0efec4db8bdd744 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyReason0efec4db8bdd744",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Reason2"
                    },
                    "lblDetailValue": {
                        "text": "reason2"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxReason2.add(CopyReason0efec4db8bdd744);
            var flxReason3 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxReason3",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxReason3.setDefaultUnit(voltmx.flex.DP);
            var CopyReason0a8e0ca5a8a5844 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyReason0a8e0ca5a8a5844",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Reason3"
                    },
                    "lblDetailValue": {
                        "text": "reason3"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxReason3.add(CopyReason0a8e0ca5a8a5844);
            flxRiskReasons.add(flxReason1, flxReason2, flxReason3);
            FlexContainer0e954e1006a6642.add(flxRiskFields, flxRiskReasons);
            flxRiskRate.add(lblHdrRiskType, RiskRateChart, FlexContainer0e954e1006a6642);
            var flxInsight = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxInsight",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsight.setDefaultUnit(voltmx.flex.DP);
            var flxCreditInsight = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxCreditInsight",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "0dp",
                "width": "49%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreditInsight.setDefaultUnit(voltmx.flex.DP);
            var SubHdr2 = new com.hcl.subHdr.SubHdr({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "45dp",
                "id": "SubHdr2",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": "0dp",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "SubHdr": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "lblSubHdr": {
                        "text": "Credit Insight"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var CopyflxAffGrid0b71a9868dde84e = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "12dp",
                "clipBounds": false,
                "id": "CopyflxAffGrid0b71a9868dde84e",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [12, 1, 12, 12],
                "paddingInPixel": true
            }, {});
            CopyflxAffGrid0b71a9868dde84e.setDefaultUnit(voltmx.flex.DP);
            var CopyflxDebitServiceRatio0g58205c511df45 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxDebitServiceRatio0g58205c511df45",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxDebitServiceRatio0g58205c511df45.setDefaultUnit(voltmx.flex.DP);
            var CopyDebitServiceRatio0ed524f8796ee4e = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyDebitServiceRatio0ed524f8796ee4e",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Debit Service Ratio"
                    },
                    "lblDetailValue": {
                        "text": "4 : 1"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxDebitServiceRatio0g58205c511df45.add(CopyDebitServiceRatio0ed524f8796ee4e);
            var CopyflxInstallToIncome0a0c95e94ffb542 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxInstallToIncome0a0c95e94ffb542",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxInstallToIncome0a0c95e94ffb542.setDefaultUnit(voltmx.flex.DP);
            var CopyInstallmentToIncome0a20f2937b88740 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyInstallmentToIncome0a20f2937b88740",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Installment To Income"
                    },
                    "lblDetailValue": {
                        "text": "18%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxInstallToIncome0a0c95e94ffb542.add(CopyInstallmentToIncome0a20f2937b88740);
            var CopyflxNetAnnIncome0cc7df3deff8943 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxNetAnnIncome0cc7df3deff8943",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxNetAnnIncome0cc7df3deff8943.setDefaultUnit(voltmx.flex.DP);
            var CopyNetAnnIncome0b486f96da31440 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyNetAnnIncome0b486f96da31440",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Net Annual Income (KES)"
                    },
                    "lblDetailValue": {
                        "text": "24,000,000"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxNetAnnIncome0cc7df3deff8943.add(CopyNetAnnIncome0b486f96da31440);
            var CopyflxSurpAvailable0e0637c52f9e146 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxSurpAvailable0e0637c52f9e146",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSurpAvailable0e0637c52f9e146.setDefaultUnit(voltmx.flex.DP);
            var CopySurplusAvailable0aae18eb4e1a849 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopySurplusAvailable0aae18eb4e1a849",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Surplus Available"
                    },
                    "lblDetailValue": {
                        "text": "4,000,000"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxSurpAvailable0e0637c52f9e146.add(CopySurplusAvailable0aae18eb4e1a849);
            CopyflxAffGrid0b71a9868dde84e.add(CopyflxDebitServiceRatio0g58205c511df45, CopyflxInstallToIncome0a0c95e94ffb542, CopyflxNetAnnIncome0cc7df3deff8943, CopyflxSurpAvailable0e0637c52f9e146);
            flxCreditInsight.add(SubHdr2, CopyflxAffGrid0b71a9868dde84e);
            var flxAffordableInsight = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxAffordableInsight",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "0dp",
                "width": "49%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxAffordableInsight.setDefaultUnit(voltmx.flex.DP);
            var lblAffSubHdr = new com.hcl.subHdr.SubHdr({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "45dp",
                "id": "lblAffSubHdr",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": "0dp",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "SubHdr": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "lblSubHdr": {
                        "text": "Affordability Insight"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAffGrid = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "12dp",
                "clipBounds": false,
                "id": "flxAffGrid",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [12, 1, 12, 12],
                "paddingInPixel": true
            }, {});
            flxAffGrid.setDefaultUnit(voltmx.flex.DP);
            var flxDebitServiceRatio = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDebitServiceRatio",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxDebitServiceRatio.setDefaultUnit(voltmx.flex.DP);
            var DebitServiceRatio = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "DebitServiceRatio",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Debit Service Ratio"
                    },
                    "lblDetailValue": {
                        "text": "4 : 1"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDebitServiceRatio.add(DebitServiceRatio);
            var flxInstallToIncome = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInstallToIncome",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInstallToIncome.setDefaultUnit(voltmx.flex.DP);
            var InstallmentToIncome = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InstallmentToIncome",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Installment To Income"
                    },
                    "lblDetailValue": {
                        "text": "18%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInstallToIncome.add(InstallmentToIncome);
            var flxNetAnnIncome = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNetAnnIncome",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxNetAnnIncome.setDefaultUnit(voltmx.flex.DP);
            var NetAnnIncome = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "NetAnnIncome",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Net Annual Income (KES)"
                    },
                    "lblDetailValue": {
                        "text": "24,000,000"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxNetAnnIncome.add(NetAnnIncome);
            var flxSurpAvailable = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSurpAvailable",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSurpAvailable.setDefaultUnit(voltmx.flex.DP);
            var SurplusAvailable = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "SurplusAvailable",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Surplus Available"
                    },
                    "lblDetailValue": {
                        "text": "4,000,000"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSurpAvailable.add(SurplusAvailable);
            flxAffGrid.add(flxDebitServiceRatio, flxInstallToIncome, flxNetAnnIncome, flxSurpAvailable);
            flxAffordableInsight.add(lblAffSubHdr, flxAffGrid);
            flxInsight.add(flxCreditInsight, flxAffordableInsight);
            var flxWatchList = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxWatchList",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxWatchList.setDefaultUnit(voltmx.flex.DP);
            var flxWatchListDetails = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxWatchListDetails",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxWatchListDetails.setDefaultUnit(voltmx.flex.DP);
            var lblSubHdrWatchList = new com.hcl.subHdr.SubHdr({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "45dp",
                "id": "lblSubHdrWatchList",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": "0dp",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "SubHdr": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "lblSubHdr": {
                        "text": "Watch List Details"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxGridWatchList = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "12dp",
                "clipBounds": false,
                "id": "flxGridWatchList",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [12, 1, 12, 12],
                "paddingInPixel": true
            }, {});
            flxGridWatchList.setDefaultUnit(voltmx.flex.DP);
            var flxWatchListYes = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxWatchListYes",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxWatchListYes.setDefaultUnit(voltmx.flex.DP);
            var WatchList = new com.hcl.lblList.LabelList({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "WatchList",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelList": {
                        "zIndex": 1
                    },
                    "flxDropDwnList": {
                        "height": "30dp",
                        "right": "3dp",
                        "top": "3dp",
                        "width": "30dp"
                    },
                    "imgDropDwn": {
                        "height": "30dp",
                        "src": "icon_dropdwn.png",
                        "top": "0dp",
                        "width": "30dp"
                    },
                    "lblDetail": {
                        "text": "Watch List"
                    },
                    "listData": {
                        "masterData": [
                            ["No", "No"],
                            ["Yes", "Yes"]
                        ],
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxWatchListYes.add(WatchList);
            var flxGroupWatchList = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxGroupWatchList",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupWatchList.setDefaultUnit(voltmx.flex.DP);
            var GroupWatchList = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "GroupWatchList",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "width": "100%",
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "Group Watchlist"
                    },
                    "txtBox": {
                        "text": "0775449345",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxGroupWatchList.add(GroupWatchList);
            var flxWatchListDate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxWatchListDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxWatchListDate.setDefaultUnit(voltmx.flex.DP);
            var WatchListDate = new voltmx.ui.Label({
                "id": "WatchListDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Watchlist Date",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var calWatchlistDate = new voltmx.ui.Calendar({
                "calendarIcon": "icon_cal.png",
                "dateComponents": [9, 9, 2015],
                "dateFormat": "dd/MM/yyyy",
                "day": 9,
                "formattedDate": "09/09/2015",
                "height": "40dp",
                "hour": 0,
                "id": "calWatchlistDate",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "month": 9,
                "seconds": 0,
                "skin": "sknSBCalender",
                "top": "5dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "year": 2015,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [16, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "noOfMonths": 1
            });
            flxWatchListDate.add(WatchListDate, calWatchlistDate);
            var flxExpLimitAmt = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxExpLimitAmt",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxExpLimitAmt.setDefaultUnit(voltmx.flex.DP);
            var ExposureLimitAmt = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "ExposureLimitAmt",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "width": "100%",
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "Exposure / Limit Amount"
                    },
                    "txtBox": {
                        "text": "15,000,000",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxExpLimitAmt.add(ExposureLimitAmt);
            var flxIrregular = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIrregular",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxIrregular.setDefaultUnit(voltmx.flex.DP);
            var Irregular = new voltmx.ui.Label({
                "id": "Irregular",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Irregular",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rdoIrregular = new voltmx.ui.RadioButtonGroup({
                "id": "rdoIrregular",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["Risk", "Risk"],
                    ["Technical", "Technical"]
                ],
                "selectedKey": "Risk",
                "skin": "slRadioButtonGroup",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIrregular.add(Irregular, rdoIrregular);
            var flxCodeStatus = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCodeStatus",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCodeStatus.setDefaultUnit(voltmx.flex.DP);
            var lblCodeStatus = new voltmx.ui.Label({
                "id": "lblCodeStatus",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Code / Status",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rdoCodeStatus = new voltmx.ui.RadioButtonGroup({
                "id": "rdoCodeStatus",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["code1", "Code 1"],
                    ["code2", "Code 2"],
                    ["code 3", "Code 3"]
                ],
                "selectedKey": "code2",
                "skin": "slRadioButtonGroup",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCodeStatus.add(lblCodeStatus, rdoCodeStatus);
            var flxReason = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxReason",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxReason.setDefaultUnit(voltmx.flex.DP);
            var LabelTextArea = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "LabelTextArea",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Reason for applicant added to watchlist"
                    },
                    "txtArea": {
                        "placeholder": "--------"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxReason.add(LabelTextArea);
            var flxWatchHistory = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxWatchHistory",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxWatchHistory.setDefaultUnit(voltmx.flex.DP);
            var WatchHistory = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "WatchHistory",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "lblText": {
                        "text": "Watchlist History"
                    },
                    "txtArea": {
                        "placeholder": "Watchlist"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxWatchHistory.add(WatchHistory);
            flxGridWatchList.add(flxWatchListYes, flxGroupWatchList, flxWatchListDate, flxExpLimitAmt, flxIrregular, flxCodeStatus, flxReason, flxWatchHistory);
            flxWatchListDetails.add(lblSubHdrWatchList, flxGridWatchList);
            flxWatchList.add(flxWatchListDetails);
            var flxBureau = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxBureau",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBureau.setDefaultUnit(voltmx.flex.DP);
            var lblSubHdrBureau = new com.hcl.subHdr.SubHdr({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "45dp",
                "id": "lblSubHdrBureau",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": "0dp",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "SubHdr": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "lblSubHdr": {
                        "text": "Credit Bureau"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxGridBureau = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "12dp",
                "clipBounds": false,
                "id": "flxGridBureau",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [12, 12, 12, 12],
                "paddingInPixel": true
            }, {});
            flxGridBureau.setDefaultUnit(voltmx.flex.DP);
            var flxCustIdentity = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCustIdentity",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustIdentity.setDefaultUnit(voltmx.flex.DP);
            var CustIdentity = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CustIdentity",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Customer Identity CIF"
                    },
                    "lblDetailValue": {
                        "text": "106000005674"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCustIdentity.add(CustIdentity);
            var flxBureauBounce = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBureauBounce",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBureauBounce.setDefaultUnit(voltmx.flex.DP);
            var BureauBounce = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BureauBounce",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Bounced Cheques"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBureauBounce.add(BureauBounce);
            var flxBureauMatch = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBureauMatch",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBureauMatch.setDefaultUnit(voltmx.flex.DP);
            var BureauMatch = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BureauMatch",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Match"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBureauMatch.add(BureauMatch);
            var flxBureauArrears = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBureauArrears",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBureauArrears.setDefaultUnit(voltmx.flex.DP);
            var BureauArrears = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BureauArrears",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Other Arrears"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBureauArrears.add(BureauArrears);
            var flxBureauStatus = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBureauStatus",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBureauStatus.setDefaultUnit(voltmx.flex.DP);
            var BureauStatus = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BureauStatus",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Status"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBureauStatus.add(BureauStatus);
            var flxBureauMaxArrears = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBureauMaxArrears",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBureauMaxArrears.setDefaultUnit(voltmx.flex.DP);
            var BureauMaxArrears = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BureauMaxArrears",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Other Arrears"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBureauMaxArrears.add(BureauMaxArrears);
            var flxBureauScore1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBureauScore1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBureauScore1.setDefaultUnit(voltmx.flex.DP);
            var BureauScore1 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BureauScore1",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Score1"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBureauScore1.add(BureauScore1);
            var flxBureauScore2 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBureauScore2",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBureauScore2.setDefaultUnit(voltmx.flex.DP);
            var BureauScore2 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BureauScore2",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Score2"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBureauScore2.add(BureauScore2);
            var flxNoOfBArrears = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNoOfBArrears",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoOfBArrears.setDefaultUnit(voltmx.flex.DP);
            var NoOfBArrears = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "NoOfBArrears",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Number Of Bureau Arrears"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxNoOfBArrears.add(NoOfBArrears);
            var flxBTotalInstal = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBTotalInstal",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBTotalInstal.setDefaultUnit(voltmx.flex.DP);
            var BTotalInstal = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BTotalInstal",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Total instalments"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBTotalInstal.add(BTotalInstal);
            var flxBScore = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBScore",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBScore.setDefaultUnit(voltmx.flex.DP);
            var BScore = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BScore",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Score"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBScore.add(BScore);
            var flxBNoRp = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBNoRp",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBNoRp.setDefaultUnit(voltmx.flex.DP);
            var BNoRp = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BNoRp",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Number Rp"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBNoRp.add(BNoRp);
            var flxBNumRpMatched = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBNumRpMatched",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBNumRpMatched.setDefaultUnit(voltmx.flex.DP);
            var BNumRpMatched = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BNumRpMatched",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Number Rp Matched"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBNumRpMatched.add(BNumRpMatched);
            var flxBNegStatus = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBNegStatus",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBNegStatus.setDefaultUnit(voltmx.flex.DP);
            var BNegStatus = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BNegStatus",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Number Rp Negative Status"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBNegStatus.add(BNegStatus);
            var flxBRpCheques = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBRpCheques",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBRpCheques.setDefaultUnit(voltmx.flex.DP);
            var BRpCheques = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BRpCheques",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Number Rp Cheques"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBRpCheques.add(BRpCheques);
            var flxBNumberRpArr = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBNumberRpArr",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBNumberRpArr.setDefaultUnit(voltmx.flex.DP);
            var BNumberRpArr = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BNumberRpArr",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Number Rp Arrears"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBNumberRpArr.add(BNumberRpArr);
            var flxBMatchRp = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBMatchRp",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBMatchRp.setDefaultUnit(voltmx.flex.DP);
            var BMatchRp = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BMatchRp",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Match Rp"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBMatchRp.add(BMatchRp);
            var flxBStatusRp = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBStatusRp",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBStatusRp.setDefaultUnit(voltmx.flex.DP);
            var BStatusRp = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BStatusRp",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Status Rp"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBStatusRp.add(BStatusRp);
            var flxBOtherArrearsRp = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBOtherArrearsRp",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBOtherArrearsRp.setDefaultUnit(voltmx.flex.DP);
            var BOtherArrearsRp = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BOtherArrearsRp",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Other Arrears Rp"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBOtherArrearsRp.add(BOtherArrearsRp);
            var flxBTotalInstalments = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBTotalInstalments",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBTotalInstalments.setDefaultUnit(voltmx.flex.DP);
            var BTotalInstalments = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BTotalInstalments",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Total Instalments Rp"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBTotalInstalments.add(BTotalInstalments);
            var flxBBouncesChequeRp = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBBouncesChequeRp",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBBouncesChequeRp.setDefaultUnit(voltmx.flex.DP);
            var BBouncesChequeRp = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BBouncesChequeRp",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Bureau Bounced Cheques Rp"
                    },
                    "lblDetailValue": {
                        "text": "0"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBBouncesChequeRp.add(BBouncesChequeRp);
            var flxExtractDate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxExtractDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 2
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxExtractDate.setDefaultUnit(voltmx.flex.DP);
            var ExtractDate = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "ExtractDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Extract Date"
                    },
                    "lblDetailValue": {
                        "text": "2023-12-09"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxExtractDate.add(ExtractDate);
            flxGridBureau.add(flxCustIdentity, flxBureauBounce, flxBureauMatch, flxBureauArrears, flxBureauStatus, flxBureauMaxArrears, flxBureauScore1, flxBureauScore2, flxNoOfBArrears, flxBTotalInstal, flxBScore, flxBNoRp, flxBNumRpMatched, flxBNegStatus, flxBRpCheques, flxBNumberRpArr, flxBMatchRp, flxBStatusRp, flxBOtherArrearsRp, flxBTotalInstalments, flxBBouncesChequeRp, flxExtractDate);
            flxBureau.add(lblSubHdrBureau, flxGridBureau);
            var flxEnvironmentSocialRisk = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxEnvironmentSocialRisk",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnvironmentSocialRisk.setDefaultUnit(voltmx.flex.DP);
            var lblSubEnvironmentSocial = new com.hcl.subHdr.SubHdr({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "45dp",
                "id": "lblSubEnvironmentSocial",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": "0dp",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "SubHdr": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "lblSubHdr": {
                        "text": "Environment and Social Risk"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxGridEnvironmentAndSocial = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "12dp",
                "clipBounds": false,
                "id": "flxGridEnvironmentAndSocial",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [12, 12, 12, 12],
                "paddingInPixel": true
            }, {});
            flxGridEnvironmentAndSocial.setDefaultUnit(voltmx.flex.DP);
            var flxEnvApplicantName = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEnvApplicantName",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnvApplicantName.setDefaultUnit(voltmx.flex.DP);
            var EnvApplicantName = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "EnvApplicantName",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Applicant Name"
                    },
                    "lblDetailValue": {
                        "text": "Ventures"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEnvApplicantName.add(EnvApplicantName);
            var flxTransRiskAss = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTransRiskAss",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransRiskAss.setDefaultUnit(voltmx.flex.DP);
            var TransRiskAss = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "TransRiskAss",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Transaction Risk Asseseement"
                    },
                    "lblDetailValue": {
                        "text": "Low"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTransRiskAss.add(TransRiskAss);
            var flxClientRiskAss = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxClientRiskAss",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxClientRiskAss.setDefaultUnit(voltmx.flex.DP);
            var ClientRiskAss = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "ClientRiskAss",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Client Risk Assessment"
                    },
                    "lblDetailValue": {
                        "text": "Low"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxClientRiskAss.add(ClientRiskAss);
            var flxReferenceNumber = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxReferenceNumber",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxReferenceNumber.setDefaultUnit(voltmx.flex.DP);
            var RefernceNumber = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "RefernceNumber",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Reference Number"
                    },
                    "lblDetailValue": {
                        "text": "2307972"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxReferenceNumber.add(RefernceNumber);
            var flxTransacOnExceptionsList = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTransacOnExceptionsList",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransacOnExceptionsList.setDefaultUnit(voltmx.flex.DP);
            var TransacExceptionList = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "TransacExceptionList",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Transaction on Exceptions List"
                    },
                    "lblDetailValue": {
                        "text": "No"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTransacOnExceptionsList.add(TransacExceptionList);
            var flxEquatorPrincipleTrans = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEquatorPrincipleTrans",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEquatorPrincipleTrans.setDefaultUnit(voltmx.flex.DP);
            var EquatorPrincipleTrans = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "EquatorPrincipleTrans",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Equator Principle Transaction "
                    },
                    "lblDetailValue": {
                        "text": "No"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEquatorPrincipleTrans.add(EquatorPrincipleTrans);
            var flxRiskAssessmentDate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRiskAssessmentDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskAssessmentDate.setDefaultUnit(voltmx.flex.DP);
            var RiskAssessmentDate = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "RiskAssessmentDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Risk Assessment Date"
                    },
                    "lblDetailValue": {
                        "text": "2023-12-07"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRiskAssessmentDate.add(RiskAssessmentDate);
            var flxRiskSocialCommentary = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRiskSocialCommentary",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRiskSocialCommentary.setDefaultUnit(voltmx.flex.DP);
            var RiskSocialCommentary = new com.hcl.lblTextArea.LabelTextArea({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "RiskSocialCommentary",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FlexContainer0e91e04f1e8e74a": {
                        "top": "5dp"
                    },
                    "LabelTextArea": {
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "Environment ad/or Socal Risk Commentary"
                    },
                    "txtArea": {
                        "placeholder": "--------"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRiskSocialCommentary.add(RiskSocialCommentary);
            flxGridEnvironmentAndSocial.add(flxEnvApplicantName, flxTransRiskAss, flxClientRiskAss, flxReferenceNumber, flxTransacOnExceptionsList, flxEquatorPrincipleTrans, flxRiskAssessmentDate, flxRiskSocialCommentary);
            flxEnvironmentSocialRisk.add(lblSubEnvironmentSocial, flxGridEnvironmentAndSocial);
            flxRiskInsight.add(flxRiskRate, flxInsight, flxWatchList, flxBureau, flxEnvironmentSocialRisk);
            var flxContInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "16dp",
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxContInfo",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxContInfo.setDefaultUnit(voltmx.flex.DP);
            var flxContactData = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "12dp",
                "clipBounds": false,
                "id": "flxContactData",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "Customer360"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContactData.setDefaultUnit(voltmx.flex.DP);
            var flxBusinessTelNum = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBusinessTelNum",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessTelNum.setDefaultUnit(voltmx.flex.DP);
            var BusinessTelNum = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "BusinessTelNum",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "width": "100%"
                    },
                    "lblText": {
                        "text": "Business Tel Number"
                    },
                    "txtBox": {
                        "text": "0775449345",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBusinessTelNum.add(BusinessTelNum);
            var flxEmailAddress = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEmailAddress",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailAddress.setDefaultUnit(voltmx.flex.DP);
            var EmailAddress = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "EmailAddress",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "width": "100%"
                    },
                    "lblText": {
                        "text": "Email Address"
                    },
                    "txtBox": {
                        "text": "info@8020marketingug.co",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEmailAddress.add(EmailAddress);
            var flxFax = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFax",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxFax.setDefaultUnit(voltmx.flex.DP);
            var Fax = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "Fax",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "width": "100%"
                    },
                    "lblText": {
                        "text": "Fax"
                    },
                    "txtBox": {
                        "placeholder": "Fax",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFax.add(Fax);
            flxContactData.add(flxBusinessTelNum, flxEmailAddress, flxFax);
            var flxPostalAddress = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPostalAddress",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "16dp",
                "width": "99%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPostalAddress.setDefaultUnit(voltmx.flex.DP);
            var flxPostalData = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPostalData",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "50%",
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPostalData.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0a06d794b2e4b41 = new voltmx.ui.Label({
                "id": "CopyLabel0a06d794b2e4b41",
                "isVisible": true,
                "left": "24dp",
                "skin": "sknLblHeading4Bold",
                "text": "Postal Address",
                "top": "16dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyFlexContainer0cea8919b3a5a43 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "12dp",
                "clipBounds": false,
                "id": "CopyFlexContainer0cea8919b3a5a43",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [12, 12, 12, 12],
                "paddingInPixel": true
            }, {});
            CopyFlexContainer0cea8919b3a5a43.setDefaultUnit(voltmx.flex.DP);
            var CopyflxStreet0hcddc934da2c48 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxStreet0hcddc934da2c48",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxStreet0hcddc934da2c48.setDefaultUnit(voltmx.flex.DP);
            var CopyStreet0i429f61e9b0b4b = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyStreet0i429f61e9b0b4b",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "Street Address"
                    },
                    "txtBox": {
                        "placeholder": "Street Address",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxStreet0hcddc934da2c48.add(CopyStreet0i429f61e9b0b4b);
            var CopyflxZipCode0dc700078f54744 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxZipCode0dc700078f54744",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxZipCode0dc700078f54744.setDefaultUnit(voltmx.flex.DP);
            var CopyZipCode0c7ef633c40d949 = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyZipCode0c7ef633c40d949",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "Zip Code"
                    },
                    "txtBox": {
                        "placeholder": "Zip Code",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxZipCode0dc700078f54744.add(CopyZipCode0c7ef633c40d949);
            var CopyflxState0db785d6795cb45 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxState0db785d6795cb45",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxState0db785d6795cb45.setDefaultUnit(voltmx.flex.DP);
            var CopyState0eb3bd5c1da4645 = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyState0eb3bd5c1da4645",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "State"
                    },
                    "txtBox": {
                        "placeholder": "State",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxState0db785d6795cb45.add(CopyState0eb3bd5c1da4645);
            var CopyflxCity0c1be6283d6524d = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxCity0c1be6283d6524d",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCity0c1be6283d6524d.setDefaultUnit(voltmx.flex.DP);
            var CopyCity0g9e44060abec47 = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCity0g9e44060abec47",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "City"
                    },
                    "txtBox": {
                        "placeholder": "City",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCity0c1be6283d6524d.add(CopyCity0g9e44060abec47);
            CopyFlexContainer0cea8919b3a5a43.add(CopyflxStreet0hcddc934da2c48, CopyflxZipCode0dc700078f54744, CopyflxState0db785d6795cb45, CopyflxCity0c1be6283d6524d);
            flxPostalData.add(CopyLabel0a06d794b2e4b41, CopyFlexContainer0cea8919b3a5a43);
            var flxPostalMap = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "350dp",
                "id": "flxPostalMap",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "8dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPostalMap.setDefaultUnit(voltmx.flex.DP);
            var mapPostal = new voltmx.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "mapPostal",
                "isVisible": true,
                "left": "120dp",
                "skin": "slImage",
                "src": "mapimage.png",
                "top": "229dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPostalMap.add(mapPostal);
            flxPostalAddress.add(flxPostalData, flxPostalMap);
            var chkAddress = new voltmx.ui.CheckBoxGroup({
                "height": "50dp",
                "id": "chkAddress",
                "isVisible": true,
                "left": "16dp",
                "masterData": [
                    ["PostaAdd", "Is postal address same as physical address"]
                ],
                "skin": "sknChkBx",
                "top": "8dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "itemOrientation": constants.CHECKBOX_ITEM_ORIENTATION_VERTICAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPhysicalAddress = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPhysicalAddress",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "16dp",
                "width": "99%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhysicalAddress.setDefaultUnit(voltmx.flex.DP);
            var flxPhysicalAddData = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPhysicalAddData",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "50%",
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhysicalAddData.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0ffc0e0209fe44a = new voltmx.ui.Label({
                "id": "CopyLabel0ffc0e0209fe44a",
                "isVisible": true,
                "left": "24dp",
                "skin": "sknLblHeading4Bold",
                "text": "Physical Address",
                "top": "16dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyFlexContainer0ae2c5f966df249 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "12dp",
                "clipBounds": false,
                "id": "CopyFlexContainer0ae2c5f966df249",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [12, 12, 12, 12],
                "paddingInPixel": true
            }, {});
            CopyFlexContainer0ae2c5f966df249.setDefaultUnit(voltmx.flex.DP);
            var CopyflxStreet0ged92e4c638f46 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxStreet0ged92e4c638f46",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxStreet0ged92e4c638f46.setDefaultUnit(voltmx.flex.DP);
            var CopyStreet0b0303562e0fa41 = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyStreet0b0303562e0fa41",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "Street Address"
                    },
                    "txtBox": {
                        "placeholder": "Street Address",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxStreet0ged92e4c638f46.add(CopyStreet0b0303562e0fa41);
            var CopyflxZipCode0c514250096fa4a = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxZipCode0c514250096fa4a",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxZipCode0c514250096fa4a.setDefaultUnit(voltmx.flex.DP);
            var CopyZipCode0ce19684f96ba47 = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyZipCode0ce19684f96ba47",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "Zip Code"
                    },
                    "txtBox": {
                        "placeholder": "Zip Code",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxZipCode0c514250096fa4a.add(CopyZipCode0ce19684f96ba47);
            var CopyflxState0bc195eda4d134f = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxState0bc195eda4d134f",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxState0bc195eda4d134f.setDefaultUnit(voltmx.flex.DP);
            var CopyState0edac75584cb84a = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyState0edac75584cb84a",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "State"
                    },
                    "txtBox": {
                        "placeholder": "State",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxState0bc195eda4d134f.add(CopyState0edac75584cb84a);
            var CopyflxCity0i4adf638fbf540 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxCity0i4adf638fbf540",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCity0i4adf638fbf540.setDefaultUnit(voltmx.flex.DP);
            var CopyCity0gd10de842da145 = new com.hcl.lblText.LabelTextBox({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCity0gd10de842da145",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "LabelTextBox": {
                        "zIndex": 1
                    },
                    "lblText": {
                        "text": "City"
                    },
                    "txtBox": {
                        "placeholder": "City",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCity0i4adf638fbf540.add(CopyCity0gd10de842da145);
            CopyFlexContainer0ae2c5f966df249.add(CopyflxStreet0ged92e4c638f46, CopyflxZipCode0c514250096fa4a, CopyflxState0bc195eda4d134f, CopyflxCity0i4adf638fbf540);
            flxPhysicalAddData.add(CopyLabel0ffc0e0209fe44a, CopyFlexContainer0ae2c5f966df249);
            var flxPhysicalMap = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "350dp",
                "id": "flxPhysicalMap",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhysicalMap.setDefaultUnit(voltmx.flex.DP);
            var CopymapPostal0b10c1be1facb47 = new voltmx.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "CopymapPostal0b10c1be1facb47",
                "isVisible": true,
                "left": "120dp",
                "skin": "slImage",
                "src": "mapimage.png",
                "top": "8dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhysicalMap.add(CopymapPostal0b10c1be1facb47);
            flxPhysicalAddress.add(flxPhysicalAddData, flxPhysicalMap);
            flxContInfo.add(flxContactData, flxPostalAddress, chkAddress, flxPhysicalAddress);
            var flxPersonalData = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPersonalData",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalData.setDefaultUnit(voltmx.flex.DP);
            var flxPersonalInfoData = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "16dp",
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxPersonalInfoData",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [12, 8, 12, 12],
                "paddingInPixel": true
            }, {});
            flxPersonalInfoData.setDefaultUnit(voltmx.flex.DP);
            var flxIncomeTax = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxIncomeTax",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxIncomeTax.setDefaultUnit(voltmx.flex.DP);
            var IncomeTax = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "IncomeTax",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Income Tax Number"
                    },
                    "lblDetailValue": {
                        "text": "2358001",
                        "top": "16dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxIncomeTax.add(IncomeTax);
            var flxDateOfBirth = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDateOfBirth",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxDateOfBirth.setDefaultUnit(voltmx.flex.DP);
            var lblDateOfBirth = new voltmx.ui.Label({
                "id": "lblDateOfBirth",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Date Of Birth",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var claDateOfBirth = new voltmx.ui.Calendar({
                "calendarIcon": "icon_cal.png",
                "dateComponents": [9, 9, 2015],
                "dateFormat": "dd/MM/yyyy",
                "day": 9,
                "formattedDate": "09/09/2015",
                "height": "40dp",
                "hour": 0,
                "id": "claDateOfBirth",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "month": 9,
                "seconds": 0,
                "skin": "sknSBCalender",
                "top": "5dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "year": 2015,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [16, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "noOfMonths": 1
            });
            flxDateOfBirth.add(lblDateOfBirth, claDateOfBirth);
            flxPersonalInfoData.add(flxIncomeTax, flxDateOfBirth);
            var flxMaritalInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "16dp",
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "flxMaritalInfo",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [12, 8, 12, 12],
                "paddingInPixel": true
            }, {});
            flxMaritalInfo.setDefaultUnit(voltmx.flex.DP);
            var CopyflxMaritalStat0j25a34e4c08c48 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxMaritalStat0j25a34e4c08c48",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxMaritalStat0j25a34e4c08c48.setDefaultUnit(voltmx.flex.DP);
            var CopyMaritalStatus0c0e6e7b632044d = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyMaritalStatus0c0e6e7b632044d",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Marital Status"
                    },
                    "lblDetailValue": {
                        "text": "Married",
                        "top": "16dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxMaritalStat0j25a34e4c08c48.add(CopyMaritalStatus0c0e6e7b632044d);
            var CopyflxConsentSpouse0bb25b51158b342 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxConsentSpouse0bb25b51158b342",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxConsentSpouse0bb25b51158b342.setDefaultUnit(voltmx.flex.DP);
            var CopylblConsentSpouse0g10f8ef0107e4c = new voltmx.ui.Label({
                "id": "CopylblConsentSpouse0g10f8ef0107e4c",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFormLevel",
                "text": "Spouse Consent Require",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyrdoHowMarried0bab3e95fe13947 = new voltmx.ui.RadioButtonGroup({
                "id": "CopyrdoHowMarried0bab3e95fe13947",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["No", "No"],
                    ["Yes", "Yes"]
                ],
                "selectedKey": "No",
                "skin": "slRadioButtonGroup",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "itemOrientation": constants.RADIOGROUP_ITEM_ORIENTATION_HORIZONTAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxConsentSpouse0bb25b51158b342.add(CopylblConsentSpouse0g10f8ef0107e4c, CopyrdoHowMarried0bab3e95fe13947);
            var CopyflxHowMarried0a57a1af762e54b = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxHowMarried0a57a1af762e54b",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxHowMarried0a57a1af762e54b.setDefaultUnit(voltmx.flex.DP);
            var CopyHowMarried0i2557a44081c41 = new com.hcl.lblList.LabelList({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyHowMarried0i2557a44081c41",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "flxDropDwnList": {
                        "height": "35dp",
                        "right": "3dp",
                        "top": "2dp",
                        "width": "35dp"
                    },
                    "imgDropDwn": {
                        "src": "icon_dropdwn.png"
                    },
                    "lblDetail": {
                        "text": "How Married"
                    },
                    "listData": {
                        "masterData": [
                            ["opt1", "ICOP"]
                        ],
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxHowMarried0a57a1af762e54b.add(CopyHowMarried0i2557a44081c41);
            var CopyflxSpouseName0c8e09239ade44b = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxSpouseName0c8e09239ade44b",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSpouseName0c8e09239ade44b.setDefaultUnit(voltmx.flex.DP);
            var CopySpouseName0ca6efba79ae944 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopySpouseName0ca6efba79ae944",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Spouse Name"
                    },
                    "lblDetailValue": {
                        "text": "Eunice Buzwani",
                        "top": "16dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxSpouseName0c8e09239ade44b.add(CopySpouseName0ca6efba79ae944);
            var CopyflxSpouseIdentityNo0i9f0b8629b0a4f = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "id": "CopyflxSpouseIdentityNo0i9f0b8629b0a4f",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSpouseIdentityNo0i9f0b8629b0a4f.setDefaultUnit(voltmx.flex.DP);
            var CopySpouseIdentityNum0a1b84f29322547 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopySpouseIdentityNum0a1b84f29322547",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Spouse Identity Number"
                    },
                    "lblDetailValue": {
                        "text": "324219679",
                        "top": "16dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxSpouseIdentityNo0i9f0b8629b0a4f.add(CopySpouseIdentityNum0a1b84f29322547);
            flxMaritalInfo.add(CopyflxMaritalStat0j25a34e4c08c48, CopyflxConsentSpouse0bb25b51158b342, CopyflxHowMarried0a57a1af762e54b, CopyflxSpouseName0c8e09239ade44b, CopyflxSpouseIdentityNo0i9f0b8629b0a4f);
            flxPersonalData.add(flxPersonalInfoData, flxMaritalInfo);
            var flxEcoGrowth = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxEcoGrowth",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_HORIZONTAL,
                "skin": "sknFlxSrcWhiteBGBlckBrdr",
                "top": "16dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxEcoGrowth.setDefaultUnit(voltmx.flex.DP);
            var flxEcoGrowthSeg = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxEcoGrowthSeg",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBGEDF5FF",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEcoGrowthSeg.setDefaultUnit(voltmx.flex.DP);
            var lblGroupNum = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblGroupNum",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n.sbc360.GroupNumber\")",
                "width": "7%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblGroupType = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblGroupType",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n.sbc360.GroupType\")",
                "width": "7%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplicantName = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblApplicantName",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Applicant Name",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIDRegNum = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblIDRegNum",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n.sbc360.ID/RegNum\")",
                "width": "7%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSegType = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblSegType",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n.sbc360.SegmentType\")",
                "width": "7%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBranch = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblBranch",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Branch",
                "width": "7%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRelationshipManager = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblRelationshipManager",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Relationship Manager",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumber = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNumber",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Account Number",
                "width": "7%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCIFNumber = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblCIFNumber",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "CIF Number",
                "width": "5%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWL = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblWL",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "WL",
                "width": "5.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEcoGrowthSeg.add(lblGroupNum, lblGroupType, lblApplicantName, lblIDRegNum, lblSegType, lblBranch, lblRelationshipManager, lblAccountNumber, lblCIFNumber, lblWL);
            var flxEcoSegData = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEcoSegData",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEcoSegData.setDefaultUnit(voltmx.flex.DP);
            var segEcoGrowth = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblAcctNum": "Label",
                    "lblApplicName": "Label",
                    "lblBranch": "Label",
                    "lblGrpNum": "Label",
                    "lblGrpType": "Label",
                    "lblIDRegNum": "Label",
                    "lblRelMang": "Label",
                    "lblSegType": "Label",
                    "lblWL": "label"
                }, {
                    "lblAcctNum": "Label",
                    "lblApplicName": "Label",
                    "lblBranch": "Label",
                    "lblGrpNum": "Label",
                    "lblGrpType": "Label",
                    "lblIDRegNum": "Label",
                    "lblRelMang": "Label",
                    "lblSegType": "Label",
                    "lblWL": "label"
                }, {
                    "lblAcctNum": "Label",
                    "lblApplicName": "Label",
                    "lblBranch": "Label",
                    "lblGrpNum": "Label",
                    "lblGrpType": "Label",
                    "lblIDRegNum": "Label",
                    "lblRelMang": "Label",
                    "lblSegType": "Label",
                    "lblWL": "label"
                }, {
                    "lblAcctNum": "Label",
                    "lblApplicName": "Label",
                    "lblBranch": "Label",
                    "lblGrpNum": "Label",
                    "lblGrpType": "Label",
                    "lblIDRegNum": "Label",
                    "lblRelMang": "Label",
                    "lblSegType": "Label",
                    "lblWL": "label"
                }, {
                    "lblAcctNum": "Label",
                    "lblApplicName": "Label",
                    "lblBranch": "Label",
                    "lblGrpNum": "Label",
                    "lblGrpType": "Label",
                    "lblIDRegNum": "Label",
                    "lblRelMang": "Label",
                    "lblSegType": "Label",
                    "lblWL": "label"
                }, {
                    "lblAcctNum": "Label",
                    "lblApplicName": "Label",
                    "lblBranch": "Label",
                    "lblGrpNum": "Label",
                    "lblGrpType": "Label",
                    "lblIDRegNum": "Label",
                    "lblRelMang": "Label",
                    "lblSegType": "Label",
                    "lblWL": "label"
                }, {
                    "lblAcctNum": "Label",
                    "lblApplicName": "Label",
                    "lblBranch": "Label",
                    "lblGrpNum": "Label",
                    "lblGrpType": "Label",
                    "lblIDRegNum": "Label",
                    "lblRelMang": "Label",
                    "lblSegType": "Label",
                    "lblWL": "label"
                }, {
                    "lblAcctNum": "Label",
                    "lblApplicName": "Label",
                    "lblBranch": "Label",
                    "lblGrpNum": "Label",
                    "lblGrpType": "Label",
                    "lblIDRegNum": "Label",
                    "lblRelMang": "Label",
                    "lblSegType": "Label",
                    "lblWL": "label"
                }, {
                    "lblAcctNum": "Label",
                    "lblApplicName": "Label",
                    "lblBranch": "Label",
                    "lblGrpNum": "Label",
                    "lblGrpType": "Label",
                    "lblIDRegNum": "Label",
                    "lblRelMang": "Label",
                    "lblSegType": "Label",
                    "lblWL": "label"
                }, {
                    "lblAcctNum": "Label",
                    "lblApplicName": "Label",
                    "lblBranch": "Label",
                    "lblGrpNum": "Label",
                    "lblGrpType": "Label",
                    "lblIDRegNum": "Label",
                    "lblRelMang": "Label",
                    "lblSegType": "Label",
                    "lblWL": "label"
                }],
                "groupCells": false,
                "id": "segEcoGrowth",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "segTrans",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "SBCommon",
                    "friendlyName": "flxRowSegEcoGrowth"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxRowSegEcoGrowth": "flxRowSegEcoGrowth",
                    "lblAcctNum": "lblAcctNum",
                    "lblApplicName": "lblApplicName",
                    "lblBranch": "lblBranch",
                    "lblGrpNum": "lblGrpNum",
                    "lblGrpType": "lblGrpType",
                    "lblIDRegNum": "lblIDRegNum",
                    "lblRelMang": "lblRelMang",
                    "lblSegType": "lblSegType",
                    "lblWL": "lblWL"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEcoSegData.add(segEcoGrowth);
            flxEcoGrowth.add(flxEcoGrowthSeg, flxEcoSegData);
            flxSrc.add(flxSrch, flxCustomerDetails, flxTabs, flxSegData, flxChart, flxCollaInfo, flxInsuranceInfo, flxOpInfo, flxRiskTypes, flxRiskInsight, flxContInfo, flxPersonalData, flxEcoGrowth);
            flxRight.add(FormHeader, flxSrc);
            flxMain.add(SideMenu, flxRight);
            var flxPopUp = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPopUp",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx15Blck",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopUp.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0f0a53cbb40a347 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "80%",
                "id": "FlexContainer0f0a53cbb40a347",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "487dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "316dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0f0a53cbb40a347.setDefaultUnit(voltmx.flex.DP);
            var flxPopUpHdr = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8%",
                "id": "flxPopUpHdr",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopUpHdr.setDefaultUnit(voltmx.flex.DP);
            var lblPopUpHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblPopUpHdr",
                "isVisible": true,
                "left": "32dp",
                "skin": "sknLblHeading2",
                "text": "Collateral",
                "top": "11dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgClose = new voltmx.ui.Image2({
                "centerY": "50%",
                "height": "35dp",
                "id": "imgClose",
                "isVisible": true,
                "right": 24,
                "skin": "slImage",
                "src": "icon_alertclose.png",
                "width": "35dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPopUpHdr.add(lblPopUpHdr, imgClose);
            var FlexContainer0a51354b25c1f4b = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "FlexContainer0a51354b25c1f4b",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [4, 8, 4, 8],
                "paddingInPixel": true
            }, {});
            FlexContainer0a51354b25c1f4b.setDefaultUnit(voltmx.flex.DP);
            var flxCustIdenNum = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCustIdenNum",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustIdenNum.setDefaultUnit(voltmx.flex.DP);
            var LabelsField = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "LabelsField",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Customer Identification Number"
                    },
                    "lblDetailValue": {
                        "text": "7680823708"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCustIdenNum.add(LabelsField);
            var flxCollateralType = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCollateralType",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollateralType.setDefaultUnit(voltmx.flex.DP);
            var CollateralTypeData = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CollateralTypeData",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Collateral_Type"
                    },
                    "lblDetailValue": {
                        "text": "IMMOVABLE PROPERTY"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCollateralType.add(CollateralTypeData);
            var flxCollateralDescp = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCollateralDescp",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollateralDescp.setDefaultUnit(voltmx.flex.DP);
            var CollateralDescp = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CollateralDescp",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Collateral_Description"
                    },
                    "lblDetailValue": {
                        "text": "Property Dco No."
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCollateralDescp.add(CollateralDescp);
            var flxCollateralStatusDesc = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCollateralStatusDesc",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollateralStatusDesc.setDefaultUnit(voltmx.flex.DP);
            var CollateralStatusDesc = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CollateralStatusDesc",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Collateral_Status_Description"
                    },
                    "lblDetailValue": {
                        "text": "Active"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCollateralStatusDesc.add(CollateralStatusDesc);
            var flxCollSecuSriNo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCollSecuSriNo",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollSecuSriNo.setDefaultUnit(voltmx.flex.DP);
            var CollSecuSriNo = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CollSecuSriNo",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Secu_Sri_Num"
                    },
                    "lblDetailValue": {
                        "text": "7680823708"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCollSecuSriNo.add(CollSecuSriNo);
            var flxCollSecuTypeInd = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCollSecuTypeInd",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollSecuTypeInd.setDefaultUnit(voltmx.flex.DP);
            var CollSecuTypeInd = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CollSecuTypeInd",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Secu_Type_Ind"
                    },
                    "lblDetailValue": {
                        "text": "1"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCollSecuTypeInd.add(CollSecuTypeInd);
            var flxSecuCode = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSecuCode",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecuCode.setDefaultUnit(voltmx.flex.DP);
            var SecuCode = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "SecuCode",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Secu_Code"
                    },
                    "lblDetailValue": {
                        "text": "RESHOME"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSecuCode.add(SecuCode);
            var flxSecDet = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSecDet",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecDet.setDefaultUnit(voltmx.flex.DP);
            var SecDet = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "SecDet",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Sec_Det"
                    },
                    "lblDetailValue": {
                        "text": "LEASE NO: 2132"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSecDet.add(SecDet);
            var flxSecuCount = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSecuCount",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecuCount.setDefaultUnit(voltmx.flex.DP);
            var SecuCoun = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "SecuCoun",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Security Count"
                    },
                    "lblDetailValue": {
                        "text": "3"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSecuCount.add(SecuCoun);
            var flxSecuValue = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSecuValue",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecuValue.setDefaultUnit(voltmx.flex.DP);
            var SecuValue = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "SecuValue",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Security Value"
                    },
                    "lblDetailValue": {
                        "text": "1276932.0998"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSecuValue.add(SecuValue);
            var flxSecuDesc = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSecuDesc",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecuDesc.setDefaultUnit(voltmx.flex.DP);
            var SecuDesc = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "SecuDesc",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Security Description"
                    },
                    "lblDetailValue": {
                        "text": "RESIDENTIAL-HOME"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSecuDesc.add(SecuDesc);
            var flxItemDueDate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxItemDueDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxItemDueDate.setDefaultUnit(voltmx.flex.DP);
            var ItemDueDate = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "ItemDueDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Item_Due_Date"
                    },
                    "lblDetailValue": {
                        "text": "2099-31-1"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxItemDueDate.add(ItemDueDate);
            var flxMaxCellingLim = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMaxCellingLim",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxMaxCellingLim.setDefaultUnit(voltmx.flex.DP);
            var MaxCellingLim = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "MaxCellingLim",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Max Celling Limit"
                    },
                    "lblDetailValue": {
                        "text": "21312"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMaxCellingLim.add(MaxCellingLim);
            var flxInsurancePolicyNo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInsurancePolicyNo",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsurancePolicyNo.setDefaultUnit(voltmx.flex.DP);
            var InsurancePolicyNo = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InsurancePolicyNo",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Insurance Policy Number"
                    },
                    "lblDetailValue": {
                        "text": "3453"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInsurancePolicyNo.add(InsurancePolicyNo);
            var flxInsuranceCompany = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInsuranceCompany",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsuranceCompany.setDefaultUnit(voltmx.flex.DP);
            var InsuranceCompany = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InsuranceCompany",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Insurance Company"
                    },
                    "lblDetailValue": {
                        "text": "SANLAM"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInsuranceCompany.add(InsuranceCompany);
            var flxInsuPolcyStartDate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInsuPolcyStartDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsuPolcyStartDate.setDefaultUnit(voltmx.flex.DP);
            var InsuPolcyStartDate = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InsuPolcyStartDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Insurance Policy Start Date"
                    },
                    "lblDetailValue": {
                        "text": "2022-06-09"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInsuPolcyStartDate.add(InsuPolcyStartDate);
            var flxInsuPolcyEndDate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInsuPolcyEndDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsuPolcyEndDate.setDefaultUnit(voltmx.flex.DP);
            var InsuPolcyEndDate = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InsuPolcyEndDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Insurancy Policy End Date"
                    },
                    "lblDetailValue": {
                        "text": "2034-05-09"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInsuPolcyEndDate.add(InsuPolcyEndDate);
            var flxInsuredItems = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInsuredItems",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsuredItems.setDefaultUnit(voltmx.flex.DP);
            var InsuredItems = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InsuredItems",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Insured Items"
                    },
                    "lblDetailValue": {
                        "text": "MOTHAE"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInsuredItems.add(InsuredItems);
            var flxInsurancePolicyAmt = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInsurancePolicyAmt",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsurancePolicyAmt.setDefaultUnit(voltmx.flex.DP);
            var InsurancePolicyAmt = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InsurancePolicyAmt",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Insurance Policy Amt"
                    },
                    "lblDetailValue": {
                        "text": "23423.9900"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInsurancePolicyAmt.add(InsurancePolicyAmt);
            var flxInspComments = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInspComments",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInspComments.setDefaultUnit(voltmx.flex.DP);
            var InspComments = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InspComments",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Insp Comments"
                    },
                    "lblDetailValue": {
                        "text": "REAL ESTATE CONSULTANT"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInspComments.add(InspComments);
            var flxInspDueDate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInspDueDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInspDueDate.setDefaultUnit(voltmx.flex.DP);
            var InspDueDate = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InspDueDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Insp Due Date"
                    },
                    "lblDetailValue": {
                        "text": "7680823708"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInspDueDate.add(InspDueDate);
            var flxInspStockValue = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInspStockValue",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInspStockValue.setDefaultUnit(voltmx.flex.DP);
            var InspStockValue = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InspStockValue",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Insp Stock Value"
                    },
                    "lblDetailValue": {
                        "text": "2343253"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInspStockValue.add(InspStockValue);
            var flxInspAdditionalNotes = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInspAdditionalNotes",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInspAdditionalNotes.setDefaultUnit(voltmx.flex.DP);
            var InspAdditionalNotes = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "InspAdditionalNotes",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Additional Notes"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInspAdditionalNotes.add(InspAdditionalNotes);
            var flxInspExtratDate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInspExtratDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInspExtratDate.setDefaultUnit(voltmx.flex.DP);
            var ExtratDate = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "ExtratDate",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "ExtratDate"
                    },
                    "lblDetailValue": {
                        "text": "2025-05-31"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInspExtratDate.add(ExtratDate);
            FlexContainer0a51354b25c1f4b.add(flxCustIdenNum, flxCollateralType, flxCollateralDescp, flxCollateralStatusDesc, flxCollSecuSriNo, flxCollSecuTypeInd, flxSecuCode, flxSecDet, flxSecuCount, flxSecuValue, flxSecuDesc, flxItemDueDate, flxMaxCellingLim, flxInsurancePolicyNo, flxInsuranceCompany, flxInsuPolcyStartDate, flxInsuPolcyEndDate, flxInsuredItems, flxInsurancePolicyAmt, flxInspComments, flxInspDueDate, flxInspStockValue, flxInspAdditionalNotes, flxInspExtratDate);
            FlexContainer0f0a53cbb40a347.add(flxPopUpHdr, FlexContainer0a51354b25c1f4b);
            flxPopUp.add(FlexContainer0f0a53cbb40a347);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "SideMenu.imgLogo": {
                    "src": "sblogo.png"
                },
                "SideMenu.imgLogout": {
                    "src": "icon_logout.png"
                },
                "FormHeader.imgLogout": {
                    "src": "icon_logout.png"
                },
                "SrchTextBox": {
                    "height": "100%",
                    "left": "0dp",
                    "top": "0dp",
                    "width": "63%"
                },
                "SrchTextBox.imgSrch": {
                    "src": "icon_srch.png"
                },
                "SubHdr": {
                    "centerY": "",
                    "top": "0dp"
                },
                "SubHdr.lblSubHdr": {
                    "text": "Customer Information"
                },
                "CIFNumber.lblDetail": {
                    "text": "CIF Number"
                },
                "CIFNumber.lblDetailValue": {
                    "height": "40dp",
                    "text": "0234567891",
                    "top": "5dp"
                },
                "EntityName": {
                    "width": "100%"
                },
                "EntityName.lblText": {
                    "text": "Entity Name"
                },
                "EntityName.txtBox": {
                    "text": "80/20 MARKETING LIMITED",
                    "width": "100%"
                },
                "EntityRegNum": {
                    "width": "100%"
                },
                "EntityRegNum.lblText": {
                    "text": "Entity Registration Number/NIF"
                },
                "EntityRegNum.txtBox": {
                    "text": "80/20 MARKETING LIMITED",
                    "width": "100%"
                },
                "EntityType.flxDropDwnList": {
                    "height": "30dp",
                    "right": "3dp",
                    "top": "3dp",
                    "width": "30dp"
                },
                "EntityType.imgDropDwn": {
                    "height": "30dp",
                    "src": "icon_dropdwn.png",
                    "top": "0dp",
                    "width": "30dp"
                },
                "EntityType.lblDetail": {
                    "text": "Entity Type"
                },
                "EntityType.listData": {
                    "width": "100%"
                },
                "IdentityNumber.flxDropDwnList": {
                    "height": "30dp",
                    "right": "3dp",
                    "top": "3dp",
                    "width": "30dp"
                },
                "IdentityNumber.imgDropDwn": {
                    "height": "30dp",
                    "src": "icon_dropdwn.png",
                    "top": "0dp",
                    "width": "30dp"
                },
                "IdentityNumber.lblDetail": {
                    "text": "Identity Number"
                },
                "IdentityNumber.listData": {
                    "width": "100%"
                },
                "FullLegalName": {
                    "width": "100%"
                },
                "FullLegalName.lblText": {
                    "text": "Full Legal Name"
                },
                "FullLegalName.txtBox": {
                    "text": "80/20 MARKETING LIMITED",
                    "width": "100%"
                },
                "RegulatorySector.flxDropDwnList": {
                    "height": "30dp",
                    "right": "3dp",
                    "top": "3dp",
                    "width": "30dp"
                },
                "RegulatorySector.imgDropDwn": {
                    "height": "30dp",
                    "src": "icon_dropdwn.png",
                    "top": "0dp",
                    "width": "30dp"
                },
                "RegulatorySector.lblDetail": {
                    "text": "Identity Number"
                },
                "RegulatorySector.listData": {
                    "width": "100%"
                },
                "ISICCode.flxDropDwnList": {
                    "height": "30dp",
                    "right": "3dp",
                    "top": "3dp",
                    "width": "30dp"
                },
                "ISICCode.imgDropDwn": {
                    "height": "30dp",
                    "src": "icon_dropdwn.png",
                    "top": "0dp",
                    "width": "30dp"
                },
                "ISICCode.lblDetail": {
                    "text": "ISIC Code"
                },
                "ISICCode.listData": {
                    "width": "100%"
                },
                "MarketSegment.flxDropDwnList": {
                    "height": "30dp",
                    "right": "3dp",
                    "top": "3dp",
                    "width": "30dp"
                },
                "MarketSegment.imgDropDwn": {
                    "height": "30dp",
                    "src": "icon_dropdwn.png",
                    "top": "0dp",
                    "width": "30dp"
                },
                "MarketSegment.lblDetail": {
                    "text": "Market Segment"
                },
                "MarketSegment.listData": {
                    "width": "100%"
                },
                "OtherBankers": {
                    "width": "100%"
                },
                "OtherBankers.lblText": {
                    "text": "Other Bankers"
                },
                "OtherBankers.txtBox": {
                    "text": "80/20 MARKETING LIMITED",
                    "width": "100%"
                },
                "RouteToHeadOff.lblDetail": {
                    "text": "Route To Head Office"
                },
                "RouteToHeadOff.lblDetailValue": {
                    "height": "40dp",
                    "text": "No"
                },
                "ApplicantsName.flxDropDwnList": {
                    "height": "30dp",
                    "right": "3dp",
                    "top": "3dp",
                    "width": "30dp"
                },
                "ApplicantsName.imgDropDwn": {
                    "height": "30dp",
                    "src": "icon_dropdwn.png",
                    "top": "0dp",
                    "width": "30dp"
                },
                "ApplicantsName.lblDetail": {
                    "text": "Applicant Name"
                },
                "ApplicantsName.listData": {
                    "width": "100%"
                },
                "IDNum.lblDetail": {
                    "text": "Route To Head Office"
                },
                "IDNum.lblDetailValue": {
                    "height": "40dp"
                },
                "SubHdr1": {
                    "centerY": "",
                    "top": "0dp"
                },
                "SubHdr1.lblSubHdr": {
                    "text": "Chart"
                },
                "linechart": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "CollateralType.lblDetail": {
                    "text": "Collateral Type / Value"
                },
                "CollateralType.lblDetailValue": {
                    "text": "Surityship Partial Liability",
                    "top": "5dp"
                },
                "LinkeAcct.lblDetail": {
                    "text": "Linked Account"
                },
                "LinkeAcct.lblDetailValue": {
                    "text": "0234567891"
                },
                "SurrenderValue.lblDetail": {
                    "text": "Surrender Value"
                },
                "SurrenderValue.lblDetailValue": {
                    "text": "R 35K"
                },
                "CopyCollateralType0c0da5ba4346d44.lblDetail": {
                    "text": "Collateral Type / Value"
                },
                "CopyCollateralType0c0da5ba4346d44.lblDetailValue": {
                    "text": "Surityship Partial Liability",
                    "top": "5dp"
                },
                "CopyLinkeAcct0df9fdc6fb25146.lblDetail": {
                    "text": "Linked Account"
                },
                "CopyLinkeAcct0df9fdc6fb25146.lblDetailValue": {
                    "text": "0234567891"
                },
                "CopySurrenderValue0ebf0965aa25740.lblDetail": {
                    "text": "Surrender Value"
                },
                "CopySurrenderValue0ebf0965aa25740.lblDetailValue": {
                    "text": "R 35K"
                },
                "CopyCollateralType0dbd8532d739946.lblDetail": {
                    "text": "Collateral Type / Value"
                },
                "CopyCollateralType0dbd8532d739946.lblDetailValue": {
                    "text": "Surityship Partial Liability",
                    "top": "5dp"
                },
                "CopyLinkeAcct0c9ef530a37af4f.lblDetail": {
                    "text": "Linked Account"
                },
                "CopyLinkeAcct0c9ef530a37af4f.lblDetailValue": {
                    "text": "0234567891"
                },
                "CopySurrenderValue0c62d8b967ddd43.lblDetail": {
                    "text": "Surrender Value"
                },
                "CopySurrenderValue0c62d8b967ddd43.lblDetailValue": {
                    "text": "R 35K"
                },
                "CopyCollateralType0eca11d9ecebf4c.lblDetail": {
                    "text": "Collateral Type / Value"
                },
                "CopyCollateralType0eca11d9ecebf4c.lblDetailValue": {
                    "text": "Surityship Partial Liability",
                    "top": "5dp"
                },
                "CopyLinkeAcct0cd84883d7da848.lblDetail": {
                    "text": "Linked Account"
                },
                "CopyLinkeAcct0cd84883d7da848.lblDetailValue": {
                    "text": "0234567891"
                },
                "CopySurrenderValue0hc8da927997147.lblDetail": {
                    "text": "Surrender Value"
                },
                "CopySurrenderValue0hc8da927997147.lblDetailValue": {
                    "text": "R 35K"
                },
                "CopyCollateralType0bbfffbf96c9042.lblDetail": {
                    "text": "Collateral Type / Value"
                },
                "CopyCollateralType0bbfffbf96c9042.lblDetailValue": {
                    "text": "Surityship Partial Liability",
                    "top": "5dp"
                },
                "CopyLinkeAcct0jea18c9afb8d49.lblDetail": {
                    "text": "Linked Account"
                },
                "CopyLinkeAcct0jea18c9afb8d49.lblDetailValue": {
                    "text": "0234567891"
                },
                "CopySurrenderValue0bb7e4d15b41d47.lblDetail": {
                    "text": "Surrender Value"
                },
                "CopySurrenderValue0bb7e4d15b41d47.lblDetailValue": {
                    "text": "R 35K"
                },
                "CopyCollateralType0f124115cfe6e4f.lblDetail": {
                    "text": "SBIB"
                },
                "CopyCollateralType0f124115cfe6e4f.lblDetailValue": {
                    "text": "SBIB",
                    "top": "5dp"
                },
                "CopyLinkeAcct0cc93bd5adfef4c.lblDetail": {
                    "text": "57687234812934"
                },
                "CopyLinkeAcct0cc93bd5adfef4c.lblDetailValue": {
                    "text": "DisabilityCover"
                },
                "CopySurrenderValue0afc66f421bb44a.lblDetail": {
                    "text": "Monthly Premium"
                },
                "CopySurrenderValue0afc66f421bb44a.lblDetailValue": {
                    "text": "R 350"
                },
                "CopyCollateralType0cd6f3a4995b943.lblDetail": {
                    "text": "SBIB"
                },
                "CopyCollateralType0cd6f3a4995b943.lblDetailValue": {
                    "text": "Old Mutual",
                    "top": "5dp"
                },
                "CopyLinkeAcct0da2e01e5fe6b4c.lblDetail": {
                    "text": "57687234812934"
                },
                "CopyLinkeAcct0da2e01e5fe6b4c.lblDetailValue": {
                    "text": "DisabilityCover"
                },
                "CopySurrenderValue0bd3f3f677bd442.lblDetail": {
                    "text": "Monthly Premium"
                },
                "CopySurrenderValue0bd3f3f677bd442.lblDetailValue": {
                    "text": "R 350"
                },
                "CopyCollateralType0hc7ba7b34a0c4d.lblDetail": {
                    "text": "SBIB"
                },
                "CopyCollateralType0hc7ba7b34a0c4d.lblDetailValue": {
                    "text": "SBIB",
                    "top": "5dp"
                },
                "CopyLinkeAcct0j9a21367001345.lblDetail": {
                    "text": "57687234812934"
                },
                "CopyLinkeAcct0j9a21367001345.lblDetailValue": {
                    "text": "DisabilityCover"
                },
                "CopySurrenderValue0d20cf40857d744.lblDetail": {
                    "text": "Monthly Premium"
                },
                "CopySurrenderValue0d20cf40857d744.lblDetailValue": {
                    "text": "R 350"
                },
                "OwnerShip.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "OwnerShip.lblText": {
                    "text": "Ownership (Shareholders & % shareholding)"
                },
                "OwnerShip.txtArea": {
                    "height": "100%",
                    "text": "Anthea Paula Turwome 40% \nArnold Patrick Samson Turwomwe 60%\ncasdasd sdcsad\n"
                },
                "DescriptionBusiness.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "DescriptionBusiness.lblText": {
                    "text": "Description Of Business "
                },
                "DescriptionBusiness.txtArea": {
                    "height": "100%",
                    "text": "Dealers in Marketing and supply of promotional materials and other general supplies\n"
                },
                "Management.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "Management.lblText": {
                    "text": "Management"
                },
                "Management.txtArea": {
                    "height": "100%",
                    "text": "Managment is composed of Benon Mascot with seventeen years of experience in business and banking professional\ncharged key Business decisions and sourcing finances.\n"
                },
                "NatureOfBussiness.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "NatureOfBussiness.lblText": {
                    "text": "Nature Of Business"
                },
                "NatureOfBussiness.txtArea": {
                    "height": "100%",
                    "text": "80/20 Marketing Ltd 80/20 Marketing Ltd for the past 6 years has been operating as a supplier for branded promotional items and also a service provider for PR Communications services with its clientele ranging from NGOs, Government and also the private sector. Today, the company has a partnership with leading South African distributor of Promotional Items called BARON and also has connections with suppliers of high quality items from China as well. The company is pre-qualified with companies like UDB, Bank of Africa, URA, ICEA, MTN Uganda, TOTALENERGIES, etc. They also look at targeting our existing clients who have repeatedly ordered from them which tells that they satisfied with their items & services and would place orders over & over again J"
                },
                "PrincipalProductRange.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "PrincipalProductRange.lblText": {
                    "text": "Principal Product Range"
                },
                "PrincipalProductRange.txtArea": {
                    "height": "100%",
                    "text": "TE Branded Promotional Items (Apparel, Drinkware, Outdoor advertising material, Business Gifts) D Office Branding • Advertising • PR Communications • Digital Marketing Ltd J"
                },
                "PPMarketPlace.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "PPMarketPlace.lblText": {
                    "text": "Position of Principal product in market place"
                },
                "PPMarketPlace.txtArea": {
                    "height": "100%",
                    "text": "The principal product of 80/20 Marketing Ltd is Branded Promotional Items. The client has positioned themselves as suppliers of high quality promotional items at affordable prices and this has enabled us serve and retain big brands like MT Uganda, TOTAL Energies, ICEA Insurance, AAR Insurance etc."
                },
                "CapitalLabourIntensity.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "CapitalLabourIntensity.lblText": {
                    "text": "Capital Labour Intensity"
                },
                "CapitalLabourIntensity.txtArea": {
                    "height": "100%",
                    "text": "80/20 Marketing Ltd runs a highly capital intensive operation and need massive amounts of capital expenditure to fulfill client's orders. Some clients order 1,000s of items with zero deposits meaning the budget is met by the company which has to wait 30-60 days to get payment. The Client employs labour but they usually come in to finished products so their main role is to do deliveries, sales and after sales\n"
                },
                "Distribution.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "Distribution.lblText": {
                    "text": "Distribution"
                },
                "Distribution.txtArea": {
                    "height": "100%",
                    "text": "80/20 Marketing receives its goods through Entebbe Airport by air freight for goods coming from South Africa and China and the East Africa Bond in Namanve for goods coming from China. The goods are kept in their store in Bwebaija on Entebbe road. Goods that are urgently needed by clients are normally moved from the bond, to our office premises for inspection and taken to client's stores.\n"
                },
                "GeographicLoc.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "GeographicLoc.lblText": {
                    "text": "Geographic Location"
                },
                "GeographicLoc.txtArea": {
                    "height": "100%",
                    "text": "80/20 Marketing is located at Plot 20, Bukoto Street - Kampala where it has had its premises for the past 6\nyears.\n"
                },
                "MainSuppCred.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "MainSuppCred.lblText": {
                    "text": "Main suppliers/creditors"
                },
                "MainSuppCred.txtArea": {
                    "height": "100%",
                    "text": "BARRON South Africa\nAMROD South Africa\nMekea Import and\nExport Company Ltd Visible Investments\n"
                },
                "MainCustSupDeb.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "MainCustSupDeb.lblText": {
                    "text": "Main customers/debtors spread"
                },
                "MainCustSupDeb.txtArea": {
                    "height": "100%",
                    "text": "MTN Uganda\nICEA Insurance\nAAR Insurance\nTotal Energies\nUganda Wildlife Authority\nWorld Health Organisation"
                },
                "DirExec.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "DirExec.lblText": {
                    "text": "Directors - Executive"
                },
                "DirExec.txtArea": {
                    "height": "100%",
                    "text": "Benon Mascot\nAnthea Turwomwe\nArnold Turwomwe\n"
                },
                "FinancialYrEnd.flxDropDwnList": {
                    "height": "30dp",
                    "right": "3dp",
                    "top": "3dp",
                    "width": "30dp"
                },
                "FinancialYrEnd.imgDropDwn": {
                    "height": "30dp",
                    "src": "icon_dropdwn.png",
                    "top": "0dp",
                    "width": "30dp"
                },
                "FinancialYrEnd.lblDetail": {
                    "text": "Financial Year End"
                },
                "FinancialYrEnd.listData": {
                    "width": "100%"
                },
                "NonExecutive.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "NonExecutive.lblText": {
                    "text": "Directors - Non-executive"
                },
                "NonExecutive.txtArea": {
                    "height": "100%"
                },
                "Competitors.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "Competitors.lblText": {
                    "text": "Competitors"
                },
                "Competitors.txtArea": {
                    "height": "100%",
                    "text": "Rocket Products Ltd\nJude Colour Solutions\nClear Media"
                },
                "Auditor.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "Auditor.lblText": {
                    "text": "Auditor"
                },
                "Auditor.txtArea": {
                    "height": "100%",
                    "text": "PANRANK & Company Plot 40 Bombo Road, Kampala"
                },
                "AccHistory.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "AccHistory.lblText": {
                    "text": "Account History"
                },
                "AccHistory.txtArea": {
                    "height": "100%",
                    "text": "Customer opened an account 9030019723797 on the 21/12/2021 domiciled at Forest Mall branch\n"
                },
                "RiskRateChart.FlexGroup0f364368a6aa841": {
                    "height": "85%"
                },
                "RiskRateChart": {
                    "height": "250dp",
                    "top": "48dp",
                    "width": "50%"
                },
                "RiskRateChart.flxPin": {
                    "centerY": "92%"
                },
                "RiskRateChart.imgChart": {
                    "height": "100%",
                    "src": "icon_rating.png"
                },
                "RiskRateChart.imgPin": {
                    "bottom": "5dp",
                    "src": "icon_pin.png"
                },
                "RiskRateChart.lblHigh": {
                    "centerY": "22%"
                },
                "RiskRateChart.lblLow": {
                    "centerX": "82%",
                    "centerY": "77%"
                },
                "RiskRateChart.lblMedium": {
                    "centerX": "70%",
                    "centerY": "36%"
                },
                "RiskRateChart.lblSubStandard": {
                    "centerX": "18%",
                    "centerY": "74%"
                },
                "RiskRateChart.lblVeryHigh": {
                    "centerX": "30%",
                    "centerY": "36%"
                },
                "ProbabilityDefault.lblDetail": {
                    "text": "Probability Of Default"
                },
                "ProbabilityDefault.lblDetailValue": {
                    "text": "12"
                },
                "RiskScoreGrade.lblDetail": {
                    "text": "Rating Score"
                },
                "RiskScoreGrade.lblDetailValue": {
                    "text": "12"
                },
                "CopyRiskScoreGrade0eb3d7cc239f542.lblDetail": {
                    "text": "Risk Grade LCY"
                },
                "CopyRiskScoreGrade0eb3d7cc239f542.lblDetailValue": {
                    "text": "LCY"
                },
                "CopyRiskScoreGrade0fa0a4b9ab6cd45.lblDetail": {
                    "text": "Risk Grade FCY"
                },
                "CopyRiskScoreGrade0fa0a4b9ab6cd45.lblDetailValue": {
                    "text": "FCY"
                },
                "CopyReason0e4a8784fb61849.lblDetail": {
                    "text": "Reason1"
                },
                "CopyReason0e4a8784fb61849.lblDetailValue": {
                    "text": "reason1"
                },
                "CopyReason0efec4db8bdd744.lblDetail": {
                    "text": "Reason2"
                },
                "CopyReason0efec4db8bdd744.lblDetailValue": {
                    "text": "reason2"
                },
                "CopyReason0a8e0ca5a8a5844.lblDetail": {
                    "text": "Reason3"
                },
                "CopyReason0a8e0ca5a8a5844.lblDetailValue": {
                    "text": "reason3"
                },
                "SubHdr2": {
                    "centerY": "",
                    "top": "0dp"
                },
                "SubHdr2.lblSubHdr": {
                    "text": "Credit Insight"
                },
                "CopyDebitServiceRatio0ed524f8796ee4e.lblDetail": {
                    "text": "Debit Service Ratio"
                },
                "CopyDebitServiceRatio0ed524f8796ee4e.lblDetailValue": {
                    "text": "4 : 1"
                },
                "CopyInstallmentToIncome0a20f2937b88740.lblDetail": {
                    "text": "Installment To Income"
                },
                "CopyInstallmentToIncome0a20f2937b88740.lblDetailValue": {
                    "text": "18%"
                },
                "CopyNetAnnIncome0b486f96da31440.lblDetail": {
                    "text": "Net Annual Income (KES)"
                },
                "CopyNetAnnIncome0b486f96da31440.lblDetailValue": {
                    "text": "24,000,000"
                },
                "CopySurplusAvailable0aae18eb4e1a849.lblDetail": {
                    "text": "Surplus Available"
                },
                "CopySurplusAvailable0aae18eb4e1a849.lblDetailValue": {
                    "text": "4,000,000"
                },
                "lblAffSubHdr": {
                    "centerY": "",
                    "top": "0dp"
                },
                "lblAffSubHdr.lblSubHdr": {
                    "text": "Affordability Insight"
                },
                "DebitServiceRatio.lblDetail": {
                    "text": "Debit Service Ratio"
                },
                "DebitServiceRatio.lblDetailValue": {
                    "text": "4 : 1"
                },
                "InstallmentToIncome.lblDetail": {
                    "text": "Installment To Income"
                },
                "InstallmentToIncome.lblDetailValue": {
                    "text": "18%"
                },
                "NetAnnIncome.lblDetail": {
                    "text": "Net Annual Income (KES)"
                },
                "NetAnnIncome.lblDetailValue": {
                    "text": "24,000,000"
                },
                "SurplusAvailable.lblDetail": {
                    "text": "Surplus Available"
                },
                "SurplusAvailable.lblDetailValue": {
                    "text": "4,000,000"
                },
                "lblSubHdrWatchList": {
                    "centerY": "",
                    "top": "0dp"
                },
                "lblSubHdrWatchList.lblSubHdr": {
                    "text": "Watch List Details"
                },
                "WatchList": {
                    "zIndex": 1
                },
                "WatchList.flxDropDwnList": {
                    "height": "30dp",
                    "right": "3dp",
                    "top": "3dp",
                    "width": "30dp"
                },
                "WatchList.imgDropDwn": {
                    "height": "30dp",
                    "src": "icon_dropdwn.png",
                    "top": "0dp",
                    "width": "30dp"
                },
                "WatchList.lblDetail": {
                    "text": "Watch List"
                },
                "WatchList.listData": {
                    "width": "100%"
                },
                "GroupWatchList": {
                    "width": "100%",
                    "zIndex": 1
                },
                "GroupWatchList.lblText": {
                    "text": "Group Watchlist"
                },
                "GroupWatchList.txtBox": {
                    "text": "0775449345",
                    "width": "100%"
                },
                "ExposureLimitAmt": {
                    "width": "100%",
                    "zIndex": 1
                },
                "ExposureLimitAmt.lblText": {
                    "text": "Exposure / Limit Amount"
                },
                "ExposureLimitAmt.txtBox": {
                    "text": "15,000,000",
                    "width": "100%"
                },
                "LabelTextArea.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "LabelTextArea.lblText": {
                    "text": "Reason for applicant added to watchlist"
                },
                "WatchHistory.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "WatchHistory.lblText": {
                    "text": "Watchlist History"
                },
                "lblSubHdrBureau": {
                    "centerY": "",
                    "top": "0dp"
                },
                "lblSubHdrBureau.lblSubHdr": {
                    "text": "Credit Bureau"
                },
                "CustIdentity.lblDetail": {
                    "text": "Customer Identity CIF"
                },
                "CustIdentity.lblDetailValue": {
                    "text": "106000005674"
                },
                "BureauBounce.lblDetail": {
                    "text": "Bureau Bounced Cheques"
                },
                "BureauBounce.lblDetailValue": {
                    "text": "0"
                },
                "BureauMatch.lblDetail": {
                    "text": "Bureau Match"
                },
                "BureauMatch.lblDetailValue": {
                    "text": "0"
                },
                "BureauArrears.lblDetail": {
                    "text": "Bureau Other Arrears"
                },
                "BureauArrears.lblDetailValue": {
                    "text": "0"
                },
                "BureauStatus.lblDetail": {
                    "text": "Bureau Status"
                },
                "BureauStatus.lblDetailValue": {
                    "text": "0"
                },
                "BureauMaxArrears.lblDetail": {
                    "text": "Bureau Other Arrears"
                },
                "BureauMaxArrears.lblDetailValue": {
                    "text": "0"
                },
                "BureauScore1.lblDetail": {
                    "text": "Bureau Score1"
                },
                "BureauScore1.lblDetailValue": {
                    "text": "0"
                },
                "BureauScore2.lblDetail": {
                    "text": "Bureau Score2"
                },
                "BureauScore2.lblDetailValue": {
                    "text": "0"
                },
                "NoOfBArrears.lblDetail": {
                    "text": "Number Of Bureau Arrears"
                },
                "NoOfBArrears.lblDetailValue": {
                    "text": "0"
                },
                "BTotalInstal.lblDetail": {
                    "text": "Bureau Total instalments"
                },
                "BTotalInstal.lblDetailValue": {
                    "text": "0"
                },
                "BScore.lblDetail": {
                    "text": "Bureau Score"
                },
                "BScore.lblDetailValue": {
                    "text": "0"
                },
                "BNoRp.lblDetail": {
                    "text": "Bureau Number Rp"
                },
                "BNoRp.lblDetailValue": {
                    "text": "0"
                },
                "BNumRpMatched.lblDetail": {
                    "text": "Bureau Number Rp Matched"
                },
                "BNumRpMatched.lblDetailValue": {
                    "text": "0"
                },
                "BNegStatus.lblDetail": {
                    "text": "Bureau Number Rp Negative Status"
                },
                "BNegStatus.lblDetailValue": {
                    "text": "0"
                },
                "BRpCheques.lblDetail": {
                    "text": "Bureau Number Rp Cheques"
                },
                "BRpCheques.lblDetailValue": {
                    "text": "0"
                },
                "BNumberRpArr.lblDetail": {
                    "text": "Bureau Number Rp Arrears"
                },
                "BNumberRpArr.lblDetailValue": {
                    "text": "0"
                },
                "BMatchRp.lblDetail": {
                    "text": "Bureau Match Rp"
                },
                "BMatchRp.lblDetailValue": {
                    "text": "0"
                },
                "BStatusRp.lblDetail": {
                    "text": "Bureau Status Rp"
                },
                "BStatusRp.lblDetailValue": {
                    "text": "0"
                },
                "BOtherArrearsRp.lblDetail": {
                    "text": "Bureau Other Arrears Rp"
                },
                "BOtherArrearsRp.lblDetailValue": {
                    "text": "0"
                },
                "BTotalInstalments.lblDetail": {
                    "text": "Bureau Total Instalments Rp"
                },
                "BTotalInstalments.lblDetailValue": {
                    "text": "0"
                },
                "BBouncesChequeRp.lblDetail": {
                    "text": "Bureau Bounced Cheques Rp"
                },
                "BBouncesChequeRp.lblDetailValue": {
                    "text": "0"
                },
                "ExtractDate.lblDetail": {
                    "text": "Extract Date"
                },
                "ExtractDate.lblDetailValue": {
                    "text": "2023-12-09"
                },
                "lblSubEnvironmentSocial": {
                    "centerY": "",
                    "top": "0dp"
                },
                "lblSubEnvironmentSocial.lblSubHdr": {
                    "text": "Environment and Social Risk"
                },
                "EnvApplicantName.lblDetail": {
                    "text": "Applicant Name"
                },
                "EnvApplicantName.lblDetailValue": {
                    "text": "Ventures"
                },
                "TransRiskAss.lblDetail": {
                    "text": "Transaction Risk Asseseement"
                },
                "TransRiskAss.lblDetailValue": {
                    "text": "Low"
                },
                "ClientRiskAss.lblDetail": {
                    "text": "Client Risk Assessment"
                },
                "ClientRiskAss.lblDetailValue": {
                    "text": "Low"
                },
                "RefernceNumber.lblDetail": {
                    "text": "Reference Number"
                },
                "RefernceNumber.lblDetailValue": {
                    "text": "2307972"
                },
                "TransacExceptionList.lblDetail": {
                    "text": "Transaction on Exceptions List"
                },
                "TransacExceptionList.lblDetailValue": {
                    "text": "No"
                },
                "EquatorPrincipleTrans.lblDetail": {
                    "text": "Equator Principle Transaction "
                },
                "EquatorPrincipleTrans.lblDetailValue": {
                    "text": "No"
                },
                "RiskAssessmentDate.lblDetail": {
                    "text": "Risk Assessment Date"
                },
                "RiskAssessmentDate.lblDetailValue": {
                    "text": "2023-12-07"
                },
                "RiskSocialCommentary.FlexContainer0e91e04f1e8e74a": {
                    "top": "5dp"
                },
                "RiskSocialCommentary": {
                    "zIndex": 1
                },
                "RiskSocialCommentary.lblText": {
                    "text": "Environment ad/or Socal Risk Commentary"
                },
                "BusinessTelNum": {
                    "width": "100%"
                },
                "BusinessTelNum.lblText": {
                    "text": "Business Tel Number"
                },
                "BusinessTelNum.txtBox": {
                    "text": "0775449345",
                    "width": "100%"
                },
                "EmailAddress": {
                    "width": "100%"
                },
                "EmailAddress.lblText": {
                    "text": "Email Address"
                },
                "EmailAddress.txtBox": {
                    "text": "info@8020marketingug.co",
                    "width": "100%"
                },
                "Fax": {
                    "width": "100%"
                },
                "Fax.lblText": {
                    "text": "Fax"
                },
                "Fax.txtBox": {
                    "width": "100%"
                },
                "CopyStreet0i429f61e9b0b4b": {
                    "zIndex": 1
                },
                "CopyStreet0i429f61e9b0b4b.lblText": {
                    "text": "Street Address"
                },
                "CopyStreet0i429f61e9b0b4b.txtBox": {
                    "width": "100%"
                },
                "CopyZipCode0c7ef633c40d949": {
                    "zIndex": 1
                },
                "CopyZipCode0c7ef633c40d949.lblText": {
                    "text": "Zip Code"
                },
                "CopyZipCode0c7ef633c40d949.txtBox": {
                    "width": "100%"
                },
                "CopyState0eb3bd5c1da4645": {
                    "zIndex": 1
                },
                "CopyState0eb3bd5c1da4645.lblText": {
                    "text": "State"
                },
                "CopyState0eb3bd5c1da4645.txtBox": {
                    "width": "100%"
                },
                "CopyCity0g9e44060abec47": {
                    "zIndex": 1
                },
                "CopyCity0g9e44060abec47.lblText": {
                    "text": "City"
                },
                "CopyCity0g9e44060abec47.txtBox": {
                    "width": "100%"
                },
                "CopyStreet0b0303562e0fa41": {
                    "zIndex": 1
                },
                "CopyStreet0b0303562e0fa41.lblText": {
                    "text": "Street Address"
                },
                "CopyStreet0b0303562e0fa41.txtBox": {
                    "width": "100%"
                },
                "CopyZipCode0ce19684f96ba47": {
                    "zIndex": 1
                },
                "CopyZipCode0ce19684f96ba47.lblText": {
                    "text": "Zip Code"
                },
                "CopyZipCode0ce19684f96ba47.txtBox": {
                    "width": "100%"
                },
                "CopyState0edac75584cb84a": {
                    "zIndex": 1
                },
                "CopyState0edac75584cb84a.lblText": {
                    "text": "State"
                },
                "CopyState0edac75584cb84a.txtBox": {
                    "width": "100%"
                },
                "CopyCity0gd10de842da145": {
                    "zIndex": 1
                },
                "CopyCity0gd10de842da145.lblText": {
                    "text": "City"
                },
                "CopyCity0gd10de842da145.txtBox": {
                    "width": "100%"
                },
                "IncomeTax.lblDetail": {
                    "text": "Income Tax Number"
                },
                "IncomeTax.lblDetailValue": {
                    "text": "2358001",
                    "top": "16dp"
                },
                "CopyMaritalStatus0c0e6e7b632044d.lblDetail": {
                    "text": "Marital Status"
                },
                "CopyMaritalStatus0c0e6e7b632044d.lblDetailValue": {
                    "text": "Married",
                    "top": "16dp"
                },
                "CopyHowMarried0i2557a44081c41.flxDropDwnList": {
                    "height": "35dp",
                    "right": "3dp",
                    "top": "2dp",
                    "width": "35dp"
                },
                "CopyHowMarried0i2557a44081c41.imgDropDwn": {
                    "src": "icon_dropdwn.png"
                },
                "CopyHowMarried0i2557a44081c41.lblDetail": {
                    "text": "How Married"
                },
                "CopyHowMarried0i2557a44081c41.listData": {
                    "width": "100%"
                },
                "CopySpouseName0ca6efba79ae944.lblDetail": {
                    "text": "Spouse Name"
                },
                "CopySpouseName0ca6efba79ae944.lblDetailValue": {
                    "text": "Eunice Buzwani",
                    "top": "16dp"
                },
                "CopySpouseIdentityNum0a1b84f29322547.lblDetail": {
                    "text": "Spouse Identity Number"
                },
                "CopySpouseIdentityNum0a1b84f29322547.lblDetailValue": {
                    "text": "324219679",
                    "top": "16dp"
                },
                "LabelsField.lblDetail": {
                    "text": "Customer Identification Number"
                },
                "LabelsField.lblDetailValue": {
                    "text": "7680823708"
                },
                "CollateralTypeData.lblDetail": {
                    "text": "Collateral_Type"
                },
                "CollateralTypeData.lblDetailValue": {
                    "text": "IMMOVABLE PROPERTY"
                },
                "CollateralDescp.lblDetail": {
                    "text": "Collateral_Description"
                },
                "CollateralDescp.lblDetailValue": {
                    "text": "Property Dco No."
                },
                "CollateralStatusDesc.lblDetail": {
                    "text": "Collateral_Status_Description"
                },
                "CollateralStatusDesc.lblDetailValue": {
                    "text": "Active"
                },
                "CollSecuSriNo.lblDetail": {
                    "text": "Secu_Sri_Num"
                },
                "CollSecuSriNo.lblDetailValue": {
                    "text": "7680823708"
                },
                "CollSecuTypeInd.lblDetail": {
                    "text": "Secu_Type_Ind"
                },
                "CollSecuTypeInd.lblDetailValue": {
                    "text": "1"
                },
                "SecuCode.lblDetail": {
                    "text": "Secu_Code"
                },
                "SecuCode.lblDetailValue": {
                    "text": "RESHOME"
                },
                "SecDet.lblDetail": {
                    "text": "Sec_Det"
                },
                "SecDet.lblDetailValue": {
                    "text": "LEASE NO: 2132"
                },
                "SecuCoun.lblDetail": {
                    "text": "Security Count"
                },
                "SecuCoun.lblDetailValue": {
                    "text": "3"
                },
                "SecuValue.lblDetail": {
                    "text": "Security Value"
                },
                "SecuValue.lblDetailValue": {
                    "text": "1276932.0998"
                },
                "SecuDesc.lblDetail": {
                    "text": "Security Description"
                },
                "SecuDesc.lblDetailValue": {
                    "text": "RESIDENTIAL-HOME"
                },
                "ItemDueDate.lblDetail": {
                    "text": "Item_Due_Date"
                },
                "ItemDueDate.lblDetailValue": {
                    "text": "2099-31-1"
                },
                "MaxCellingLim.lblDetail": {
                    "text": "Max Celling Limit"
                },
                "MaxCellingLim.lblDetailValue": {
                    "text": "21312"
                },
                "InsurancePolicyNo.lblDetail": {
                    "text": "Insurance Policy Number"
                },
                "InsurancePolicyNo.lblDetailValue": {
                    "text": "3453"
                },
                "InsuranceCompany.lblDetail": {
                    "text": "Insurance Company"
                },
                "InsuranceCompany.lblDetailValue": {
                    "text": "SANLAM"
                },
                "InsuPolcyStartDate.lblDetail": {
                    "text": "Insurance Policy Start Date"
                },
                "InsuPolcyStartDate.lblDetailValue": {
                    "text": "2022-06-09"
                },
                "InsuPolcyEndDate.lblDetail": {
                    "text": "Insurancy Policy End Date"
                },
                "InsuPolcyEndDate.lblDetailValue": {
                    "text": "2034-05-09"
                },
                "InsuredItems.lblDetail": {
                    "text": "Insured Items"
                },
                "InsuredItems.lblDetailValue": {
                    "text": "MOTHAE"
                },
                "InsurancePolicyAmt.lblDetail": {
                    "text": "Insurance Policy Amt"
                },
                "InsurancePolicyAmt.lblDetailValue": {
                    "text": "23423.9900"
                },
                "InspComments.lblDetail": {
                    "text": "Insp Comments"
                },
                "InspComments.lblDetailValue": {
                    "text": "REAL ESTATE CONSULTANT"
                },
                "InspDueDate.lblDetail": {
                    "text": "Insp Due Date"
                },
                "InspDueDate.lblDetailValue": {
                    "text": "7680823708"
                },
                "InspStockValue.lblDetail": {
                    "text": "Insp Stock Value"
                },
                "InspStockValue.lblDetailValue": {
                    "text": "2343253"
                },
                "InspAdditionalNotes.lblDetail": {
                    "text": "Additional Notes"
                },
                "ExtratDate.lblDetail": {
                    "text": "ExtratDate"
                },
                "ExtratDate.lblDetailValue": {
                    "text": "2025-05-31"
                }
            }
            this.add(flxMain, flxPopUp);
        };
        return [{
            "addWidgets": addWidgetsfrmCustomer,
            "enabledForIdleTimeout": false,
            "id": "frmCustomer",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmBG",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "Customer360"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});