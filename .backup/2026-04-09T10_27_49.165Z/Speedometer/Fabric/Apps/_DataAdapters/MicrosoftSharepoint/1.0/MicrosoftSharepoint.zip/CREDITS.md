## RAML is constructed from below links

https://developer.microsoft.com/en-us/graph/graph-explorer
https://docs.microsoft.com/en-us/graph/api/resources/sharepoint?view=graph-rest-1.0

