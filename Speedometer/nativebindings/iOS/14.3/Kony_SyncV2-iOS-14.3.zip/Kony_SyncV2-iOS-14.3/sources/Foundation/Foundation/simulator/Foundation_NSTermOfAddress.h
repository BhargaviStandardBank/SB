#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Foundation_NSTermOfAddress_symbols(JSContext*);
@protocol NSTermOfAddressInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy) NSString * languageIdentifier;
@property (readonly,copy) NSArray * pronouns;
@end
@protocol NSTermOfAddressClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(id) neutral;
+(id) feminine;
+(id) masculine;
+(id) localizedForLanguageIdentifier: (NSString *) language withPronouns: (NSArray *) pronouns ;
@end
#pragma clang diagnostic pop