define("Customer360/frmCustomer", function() {
    return function(controller) {
        function addWidgetsfrmCustomer() {
            this.setDefaultUnit(voltmx.flex.DP);
            var flxMain = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(voltmx.flex.DP);
            var flxLeft = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxWhiteBdr",
                "width": "15%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(voltmx.flex.DP);
            var SideMenu = new com.hcl.menu.SideMenu({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "focusSkin": "sknFlxTrans",
                "height": "100%",
                "id": "SideMenu",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(SideMenu);
            var flxRight = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRight",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(voltmx.flex.DP);
            var FormHeader = new com.hcl.hdr.FormHeader({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "focusSkin": "sknFlxTrans",
                "height": "8%",
                "id": "FormHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "FormHeader": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "lblHdr": {
                        "text": "Customer Information"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxSrc = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "825dp",
                "horizontalScrollIndicator": true,
                "id": "flxSrc",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "24dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "sknFlxSrcTrans",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "96%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxSrc.setDefaultUnit(voltmx.flex.DP);
            var flxCustomerDetails = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCustomerDetails",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerDetails.setDefaultUnit(voltmx.flex.DP);
            var SubHdr = new com.hcl.subHdr.SubHdr({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "45dp",
                "id": "SubHdr",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": "0dp",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "SubHdr": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "lblSubHdr": {
                        "text": "CustomerName"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCustomerInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "gutterX": "12dp",
                "gutterY": "16dp",
                "clipBounds": false,
                "id": "flxCustomerInfo",
                "isVisible": true,
                "layoutType": voltmx.flex.RESPONSIVE_GRID,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [16, 12, 16, 16],
                "paddingInPixel": true
            }, {});
            flxCustomerInfo.setDefaultUnit(voltmx.flex.DP);
            var flxCustomerNumber = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCustomerNumber",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerNumber.setDefaultUnit(voltmx.flex.DP);
            var CustomerNumber = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CustomerNumber",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Customer Number"
                    },
                    "lblDetailValue": {
                        "text": "0234567891",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCustomerNumber.add(CustomerNumber);
            var flxCustomerID = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCustomerID",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerID.setDefaultUnit(voltmx.flex.DP);
            var CustomerID = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CustomerID",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Customer ID"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCustomerID.add(CustomerID);
            var flxPreferredContact = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPreferredContact",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxPreferredContact.setDefaultUnit(voltmx.flex.DP);
            var PrefferedContact = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "PrefferedContact",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Prefered Contact (Mobile)"
                    },
                    "lblDetailValue": {
                        "text": "0986367723"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPreferredContact.add(PrefferedContact);
            var flxContactNumber = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContactNumber",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxContactNumber.setDefaultUnit(voltmx.flex.DP);
            var ContactNumber = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "ContactNumber",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Contact Number"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxContactNumber.add(ContactNumber);
            var flxEmailAddress = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEmailAddress",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailAddress.setDefaultUnit(voltmx.flex.DP);
            var EmailAddress = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "EmailAddress",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "E-Mail Address"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEmailAddress.add(EmailAddress);
            var flxEmploymentStatus = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEmploymentStatus",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmploymentStatus.setDefaultUnit(voltmx.flex.DP);
            var EmploymentStatus = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "EmploymentStatus",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Employement Status"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEmploymentStatus.add(EmploymentStatus);
            var flxCustomerType = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCustomerType",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerType.setDefaultUnit(voltmx.flex.DP);
            var CustomerType = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CustomerType",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Customer Type"
                    },
                    "lblDetailValue": {
                        "text": "Personal"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCustomerType.add(CustomerType);
            var flxStaffIndicator = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxStaffIndicator",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxStaffIndicator.setDefaultUnit(voltmx.flex.DP);
            var StaffIndicator = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "StaffIndicator",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Staff Indicator"
                    },
                    "lblDetailValue": {
                        "text": "Yes / No"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxStaffIndicator.add(StaffIndicator);
            var flxRelationShipMan = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRelationShipMan",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxRelationShipMan.setDefaultUnit(voltmx.flex.DP);
            var RelationShipMan = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "RelationShipMan",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Relationship Manager"
                    },
                    "lblDetailValue": {
                        "text": "N/A"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRelationShipMan.add(RelationShipMan);
            var flxCustomerLevelStatus = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCustomerLevelStatus",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerLevelStatus.setDefaultUnit(voltmx.flex.DP);
            var CustomerLevelStatus = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CustomerLevelStatus",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Customer Level Status"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCustomerLevelStatus.add(CustomerLevelStatus);
            var CopyflxCustomerNumber0hb50bcb9fbd047 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxCustomerNumber0hb50bcb9fbd047",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCustomerNumber0hb50bcb9fbd047.setDefaultUnit(voltmx.flex.DP);
            var CopyCustomerNumber0g030e9cfec1d49 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCustomerNumber0g030e9cfec1d49",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Customer Number"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCustomerNumber0hb50bcb9fbd047.add(CopyCustomerNumber0g030e9cfec1d49);
            var CopyflxCustomerNumber0bfc204f2af274a = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxCustomerNumber0bfc204f2af274a",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 4
                    }
                },
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxCustomerNumber0bfc204f2af274a.setDefaultUnit(voltmx.flex.DP);
            var CopyCustomerNumber0dd4a62f47c3942 = new com.hcl.labelField.LabelsField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "CopyCustomerNumber0dd4a62f47c3942",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "lblDetail": {
                        "text": "Customer Number"
                    },
                    "lblDetailValue": {
                        "text": "0234567891"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CopyflxCustomerNumber0bfc204f2af274a.add(CopyCustomerNumber0dd4a62f47c3942);
            flxCustomerInfo.add(flxCustomerNumber, flxCustomerID, flxPreferredContact, flxContactNumber, flxEmailAddress, flxEmploymentStatus, flxCustomerType, flxStaffIndicator, flxRelationShipMan, flxCustomerLevelStatus, CopyflxCustomerNumber0hb50bcb9fbd047, CopyflxCustomerNumber0bfc204f2af274a);
            flxCustomerDetails.add(SubHdr, flxCustomerInfo);
            var flxTabs = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTabs",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "24dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabs.setDefaultUnit(voltmx.flex.DP);
            var flxInternalExpo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInternalExpo",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "10%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInternalExpo.setDefaultUnit(voltmx.flex.DP);
            var lblIntrnalExpo = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblIntrnalExpo",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Internal Exposure",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInternalLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxInternalLine",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInternalLine.setDefaultUnit(voltmx.flex.DP);
            flxInternalLine.add();
            flxInternalExpo.add(lblIntrnalExpo, flxInternalLine);
            var flxFixedAssets = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFixedAssets",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "8%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxFixedAssets.setDefaultUnit(voltmx.flex.DP);
            var lblFixedAssets = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblFixedAssets",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Fixed Assets",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFixedLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxFixedLine",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxFixedLine.setDefaultUnit(voltmx.flex.DP);
            flxFixedLine.add();
            flxFixedAssets.add(lblFixedAssets, flxFixedLine);
            var flxCollateral = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCollateral",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "6%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollateral.setDefaultUnit(voltmx.flex.DP);
            var lblCollateral = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblCollateral",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Collateral",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCollateralLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxCollateralLine",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxCollateralLine.setDefaultUnit(voltmx.flex.DP);
            flxCollateralLine.add();
            flxCollateral.add(lblCollateral, flxCollateralLine);
            var flxInsuranceAss = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxInsuranceAss",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxTrans",
                "top": "0",
                "width": "13%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsuranceAss.setDefaultUnit(voltmx.flex.DP);
            var lblInsuranceAss = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblInsuranceAss",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblHeading4Bold",
                "text": "Insurance / Assurance",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInsuranceLine = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "5dp",
                "id": "flxInsuranceLine",
                "isVisible": false,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBlue",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxInsuranceLine.setDefaultUnit(voltmx.flex.DP);
            flxInsuranceLine.add();
            flxInsuranceAss.add(lblInsuranceAss, flxInsuranceLine);
            flxTabs.add(flxInternalExpo, flxFixedAssets, flxCollateral, flxInsuranceAss);
            var flxSegData = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegData",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegData.setDefaultUnit(voltmx.flex.DP);
            var flxSegHdr = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSegHdr",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBGEDF5FF",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegHdr.setDefaultUnit(voltmx.flex.DP);
            var lblAcctTypeHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblAcctTypeHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Account Type",
                "width": "8%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAcctNoHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblAcctNoHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Account No",
                "width": "7%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBRIHdr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblBRIHdr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "BRI",
                "width": "3%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutStandingBalHDr = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblOutStandingBalHDr",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "width": "8%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblAcctTypeHdr0cd7f1260775446 = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "CopylblAcctTypeHdr0cd7f1260775446",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Installement",
                "width": "7%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblAcctTypeHdr0c03a68c9e84a47 = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "CopylblAcctTypeHdr0c03a68c9e84a47",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Arrears Excess",
                "width": "9%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblAcctTypeHdr0e362ce3556ff48 = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "CopylblAcctTypeHdr0e362ce3556ff48",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Amount Due",
                "width": "7.10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblAcctTypeHdr0d92851bd2ae44a = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "CopylblAcctTypeHdr0d92851bd2ae44a",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Original Loan Amount",
                "width": "8%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblAcctTypeHdr0gedbd0a8c69049 = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "CopylblAcctTypeHdr0gedbd0a8c69049",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Original Limit",
                "width": "7.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblAcctTypeHdr0a008424f14b44d = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "CopylblAcctTypeHdr0a008424f14b44d",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Current Limit",
                "width": "7.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInterestRate = new voltmx.ui.Label({
                "centerY": "50%",
                "id": "lblInterestRate",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblFormLevel",
                "text": "Interest Rate",
                "width": "5%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegHdr.add(lblAcctTypeHdr, lblAcctNoHdr, lblBRIHdr, lblOutStandingBalHDr, CopylblAcctTypeHdr0cd7f1260775446, CopylblAcctTypeHdr0c03a68c9e84a47, CopylblAcctTypeHdr0e362ce3556ff48, CopylblAcctTypeHdr0d92851bd2ae44a, CopylblAcctTypeHdr0gedbd0a8c69049, CopylblAcctTypeHdr0a008424f14b44d, lblInterestRate);
            var flxSeg = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "slFFocusbox",
                "height": "300dp",
                "id": "flxSeg",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeg.setDefaultUnit(voltmx.flex.DP);
            var segInternalExposure = new voltmx.ui.SegmentedUI2({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "data": [{
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOutstandingBal": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOutstandingBal": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOutstandingBal": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOutstandingBal": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOutstandingBal": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOutstandingBal": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOutstandingBal": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOutstandingBal": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOutstandingBal": "Label"
                }, {
                    "lblAccNo": "Label",
                    "lblAcctType": "Label",
                    "lblAmountDue": "Label",
                    "lblArrearsExcess": "Label",
                    "lblBRI": "Label",
                    "lblCurrentLimit": "Label",
                    "lblInstalment": "Label",
                    "lblInterestRate": "Label",
                    "lblOrgLimit": "label",
                    "lblOrgLoanAmt": "Label",
                    "lblOutstandingBal": "Label"
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segInternalExposure",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "SBCommon",
                    "friendlyName": "flxRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxRow": "flxRow",
                    "lblAccNo": "lblAccNo",
                    "lblAcctType": "lblAcctType",
                    "lblAmountDue": "lblAmountDue",
                    "lblArrearsExcess": "lblArrearsExcess",
                    "lblBRI": "lblBRI",
                    "lblCurrentLimit": "lblCurrentLimit",
                    "lblInstalment": "lblInstalment",
                    "lblInterestRate": "lblInterestRate",
                    "lblOrgLimit": "lblOrgLimit",
                    "lblOrgLoanAmt": "lblOrgLoanAmt",
                    "lblOutstandingBal": "lblOutstandingBal"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeg.add(segInternalExposure);
            flxSegData.add(flxSegHdr, flxSeg);
            var flxChart = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "400dp",
                "id": "flxChart",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxWhiteBGBlckBrdr",
                "top": "34dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Customer360"
            }, {
                "paddingInPixel": false
            }, {});
            flxChart.setDefaultUnit(voltmx.flex.DP);
            var SubHdr1 = new com.hcl.subHdr.SubHdr({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "45dp",
                "id": "SubHdr1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxTrans",
                "top": "0dp",
                "zIndex": 1,
                "appName": "SBCommon",
                "overrides": {
                    "SubHdr": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    },
                    "lblSubHdr": {
                        "text": "Chart"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var linechart = new com.konymp.linechart({
                "height": "100%",
                "id": "linechart",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "Customer360",
                "viewType": "linechart",
                "overrides": {
                    "linechart": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            linechart.chartTitle = "Line Chart";
            linechart.chartData = {
                "data": [{
                    "dataVal": "9",
                    "lblName": "data1"
                }, {
                    "dataVal": "2",
                    "lblName": "data2"
                }, {
                    "dataVal": "5",
                    "lblName": "data3"
                }, {
                    "dataVal": "12",
                    "lblName": "data4"
                }],
                "schema": [{
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Label Name",
                    "columnHeaderType": "text",
                    "columnID": "lblName",
                    "columnOnClick": null,
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "f1a80a1c509a45d0ad84b3097d1e8cb7"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Value",
                    "columnHeaderType": "text",
                    "columnID": "dataVal",
                    "columnOnClick": null,
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "c4dc7111a5f24c0da4cf8236ddad5233"
                }]
            };
            linechart.enableGrid = true;
            linechart.xAxisTitle = "x-axis";
            linechart.yAxisTitle = "y-axis";
            linechart.lowValue = "0";
            linechart.titleFontColor = "#000000";
            linechart.enableGridAnimation = true;
            linechart.titleFontSize = "12";
            linechart.highValue = "40";
            linechart.lineColor = "#1B9ED9";
            linechart.bgColor = "#FFFFFF";
            linechart.enableChartAnimation = true;
            linechart.enableStaticPreview = true;
            flxChart.add(SubHdr1, linechart);
            flxSrc.add(flxCustomerDetails, flxTabs, flxSegData, flxChart);
            flxRight.add(FormHeader, flxSrc);
            flxMain.add(flxLeft, flxRight);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "FormHeader": {
                    "centerY": "",
                    "top": "0dp"
                },
                "FormHeader.lblHdr": {
                    "text": "Customer Information"
                },
                "SubHdr": {
                    "centerY": "",
                    "top": "0dp"
                },
                "SubHdr.lblSubHdr": {
                    "text": "CustomerName"
                },
                "CustomerNumber.lblDetail": {
                    "text": "Customer Number"
                },
                "CustomerNumber.lblDetailValue": {
                    "text": "0234567891",
                    "top": "5dp"
                },
                "CustomerID.lblDetail": {
                    "text": "Customer ID"
                },
                "CustomerID.lblDetailValue": {
                    "text": "0234567891"
                },
                "PrefferedContact.lblDetail": {
                    "text": "Prefered Contact (Mobile)"
                },
                "PrefferedContact.lblDetailValue": {
                    "text": "0986367723"
                },
                "ContactNumber.lblDetail": {
                    "text": "Contact Number"
                },
                "ContactNumber.lblDetailValue": {
                    "text": "0234567891"
                },
                "EmailAddress.lblDetail": {
                    "text": "E-Mail Address"
                },
                "EmailAddress.lblDetailValue": {
                    "text": "0234567891"
                },
                "EmploymentStatus.lblDetail": {
                    "text": "Employement Status"
                },
                "EmploymentStatus.lblDetailValue": {
                    "text": "0234567891"
                },
                "CustomerType.lblDetail": {
                    "text": "Customer Type"
                },
                "CustomerType.lblDetailValue": {
                    "text": "Personal"
                },
                "StaffIndicator.lblDetail": {
                    "text": "Staff Indicator"
                },
                "StaffIndicator.lblDetailValue": {
                    "text": "Yes / No"
                },
                "RelationShipMan.lblDetail": {
                    "text": "Relationship Manager"
                },
                "RelationShipMan.lblDetailValue": {
                    "text": "N/A"
                },
                "CustomerLevelStatus.lblDetail": {
                    "text": "Customer Level Status"
                },
                "CustomerLevelStatus.lblDetailValue": {
                    "text": "0234567891"
                },
                "CopyCustomerNumber0g030e9cfec1d49.lblDetail": {
                    "text": "Customer Number"
                },
                "CopyCustomerNumber0g030e9cfec1d49.lblDetailValue": {
                    "text": "0234567891"
                },
                "CopyCustomerNumber0dd4a62f47c3942.lblDetail": {
                    "text": "Customer Number"
                },
                "CopyCustomerNumber0dd4a62f47c3942.lblDetailValue": {
                    "text": "0234567891"
                },
                "SubHdr1": {
                    "centerY": "",
                    "top": "0dp"
                },
                "SubHdr1.lblSubHdr": {
                    "text": "Chart"
                },
                "linechart": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmCustomer,
            "enabledForIdleTimeout": false,
            "id": "frmCustomer",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmBG",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "Customer360"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});