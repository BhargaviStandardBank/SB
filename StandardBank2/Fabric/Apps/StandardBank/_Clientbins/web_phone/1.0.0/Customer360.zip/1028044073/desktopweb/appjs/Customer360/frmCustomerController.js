define("Customer360/userfrmCustomerController", {
    /** ---------------- STATE ---------------- **/
    _masterFinancialData: [],
    /** ---------------- ENTRY ---------------- **/
    onNavigate() {
        this._setupDataMap();
        this._initializeTabActions();
        this._initializeView().catch(err => {
            throw new Error(`Form Initialization Failed: ${err.message}`);
        }); // Throwing exception instead of print
    },
    /** ---------------- DATA MAPPING ---------------- **/
    _setupDataMap() {
        this.view.lblOutStandingBalHDr.text = "Outstanding \n   Balance";
        this.view.segInternalExposure.widgetDataMap = {
            lblAcctType: "lblAcctType",
            lblAccNo: "lblAccNo",
            lblBRI: "lblBRI",
            lblOutstandingBal: "lblOutstandingBal",
            lblInstalment: "lblInstalment",
            lblArrearsExcess: "lblArrearsExcess",
            lblAmountDue: "lblAmountDue",
            lblOrgLoanAmt: "lblOrgLoanAmt",
            lblOrgLimit: "lblOrgLimit",
            lblCurrentLimit: "lblCurrentLimit",
            lblInterestRate: "lblInterestRate",
            lblDate: "lblDate",
            lblTerm: "lblTerm",
            lblRem: "lblRem",
            flxRow: "flxRow"
        };
    },
    /** ---------------- ACTIONS ---------------- **/
    _initializeTabActions() {
        // Tab Click Events
        this.view.flxInternalExpo.onClick = () => this._switchTab("INTERNAL");
        this.view.flxFixedAssets.onClick = () => this._switchTab("FIXED");
        this.view.flxCollateral.onClick = () => this._switchTab("COLLATERAL");
        this.view.flxInsuranceAss.onClick = () => this._switchTab("INSURANCE");
    },
    _switchTab(tabName) {
        this.view.flxInternalLine.isVisible = (tabName === "INTERNAL");
        this.view.flxFixedLine.isVisible = (tabName === "FIXED");
        this.view.flxCollateralLine.isVisible = (tabName === "COLLATERAL");
        this.view.flxInsuranceLine.isVisible = (tabName === "INSURANCE");
    },
    /** ---------------- ASYNC DATA LOADING ---------------- **/
    /**
     * Initializes the view by fetching global data
     * @returns {Promise<boolean>}
     */
    _initializeView() {
        return new Promise((resolve, reject) => {
            try {
                // ES6 Spread operator for default parameters/cloning
                this._masterFinancialData = [...GlobalData.financialRecords];
                this._renderSegment(this._masterFinancialData);
                resolve(true);
            } catch (error) {
                reject(new Error(`Failed to load global data: ${error.message}`));
            }
        });
    },
    /** ---------------- RENDER LOGIC ---------------- **/
    /**
     * Maps data to the segment with performance optimization
     * @param {Array} data - The array of financial records
     */
    _renderSegment(data = []) {
        const processedData = data.map(item => {
            // ES6 Destructuring for clean variable access
            const {
                type,
                accNo,
                bri,
                balance,
                instalment,
                arrears,
                due,
                origAmount,
                origLimit,
                currLimit,
                rate,
                date,
                term,
                rem
            } = item;
            // ES6 Ternary operator for conditional row skinning
            //const rowSkin = type === "HMLN" ? "sknRowBlueHighlight" : "sknRowWhite";
            return {
                //flxRow: { skin: rowSkin },
                lblAcctType: type,
                lblAccNo: accNo,
                lblBRI: bri,
                lblOutstandingBal: balance,
                lblInstalment: instalment,
                lblArrearsExcess: arrears,
                lblAmountDue: due,
                lblOrgLoanAmt: origAmount,
                lblOrgLimit: origLimit,
                lblCurrentLimit: currLimit,
                lblInterestRate: rate,
                lblDate: date,
                lblTerm: term,
                lblRem: rem
            };
        });
        this.view.segInternalExposure.setData(processedData);
        /** * BATCHING AND PERFORMANCE DOCUMENTATION:
         * forceLayout ensures that all 14+ labels per row have their dimensions 
         * calculated in a single UI thread pass. This is critical for 
         * high-density forms to prevent flickering and lag.
         */
        this.view.forceLayout();
    }
});
define("Customer360/frmCustomerControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Customer360/frmCustomerController", ["Customer360/userfrmCustomerController", "Customer360/frmCustomerControllerActions"], function() {
    var controller = require("Customer360/userfrmCustomerController");
    var controllerActions = ["Customer360/frmCustomerControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
